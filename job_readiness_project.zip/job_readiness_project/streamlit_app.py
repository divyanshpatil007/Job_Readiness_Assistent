# import streamlit as st
# from self_assessment.assessment import ask_questions, calculate_score, get_assessment_result
# from interview_bot.bot import run_interview
# from resume_checker.parser import parse_resume
# from resume_checker.ats_scoring import ats_score
# import traceback

# # Set page config
# st.set_page_config(
#     page_title="Job Readiness Assistant",
#     page_icon="💼",
#     layout="wide",
#     initial_sidebar_state="expanded"
# )

# def self_assessment_section():
#     """Enhanced Self Assessment section"""
#     st.subheader("📊 Self Assessment")
#     with st.expander("About this section"):
#         st.write("Evaluate your job readiness through carefully designed questions that assess key competencies.")
    
#     questions = ask_questions()
#     responses = []
    
#     for i, q in enumerate(questions):
#         st.markdown(f"#### {i+1}. {q['question']}")
#         response = st.radio(
#             "Select your answer:",
#             q['options'],
#             key=f"self_assess_q{i}",
#             index=None  # Forces user to make a selection
#         )
#         if response is None:
#             st.warning("Please select an answer to proceed")
#             return
#         responses.append(q['scores'][q['options'].index(response)])
    
#     if st.button("📊 Calculate Score", use_container_width=True):
#         score = calculate_score(responses)
#         result = get_assessment_result(score)
#         st.session_state.self_assessment_score = score
        
#         st.success("### Assessment Completed!")
#         col1, col2 = st.columns(2)
#         with col1:
#             st.metric("Your Score", f"{score}/100")
#         with col2:
#             st.metric("Result", result)
        
#         # Dynamic feedback based on score
#         st.subheader("📝 Feedback")
#         if score < 50:
#             st.error("**Areas for Improvement**")
#             st.write("""
#             - Focus on skill development in your weak areas
#             - Create a career development plan
#             - Seek mentorship or training opportunities
#             """)
#         elif score < 80:
#             st.warning("**Good Progress**")
#             st.write("""
#             - Strengthen your interview skills
#             - Refine your career goals
#             - Expand your professional network
#             """)
#         else:
#             st.success("**Excellent Readiness**")
#             st.write("""
#             - Continue maintaining your skills
#             - Consider leadership opportunities
#             - Mentor others in your field
#             """)

# def resume_checker_section():
#     st.subheader("📄 Resume Checker")
    
#     # Optional job description input
#     with st.expander("Add Job Description (Optional)"):
#         job_description = st.text_area(
#             "Paste the job description to get more targeted feedback",
#             height=200,
#             help="Adding a job description will help analyze how well your resume matches the specific role"
#         )
    
#     uploaded_file = st.file_uploader("Upload your resume (PDF)", type=["pdf"])
    
#     if uploaded_file:
#         with st.spinner("Analyzing your resume..."):
#             try:
#                 text = parse_resume(uploaded_file)
                
#                 # Pass job description if provided
#                 job_desc = job_description if job_description and job_description.strip() else None
#                 result = ats_score(text, job_desc)
                
#                 if 'error' in result:
#                     st.error(f"Analysis failed: {result['error']}")
#                     with st.expander("View Error Details"):
#                         st.text(result.get('parsed_text', ''))
#                     return
                
#                 # Store results in session state
#                 st.session_state.resume_data = result
#                 st.session_state.resume_score = result['percentage']
                
#                 # Display results
#                 st.success(f"Analysis Complete! Score: {result['percentage']}%")
                
#                 col1, col2 = st.columns(2)
#                 with col1:
#                     st.metric("ATS Score", f"{result['percentage']}%")
#                 with col2:
#                     st.progress(result['percentage']/100)
                
#                 # Show warnings if any
#                 if result.get('warnings', []):
#                     with st.expander("⚠️ Processing Notes"):
#                         for warning in result['warnings']:
#                             st.warning(warning)
                
#                 # Detailed breakdown
#                 with st.expander("📊 Detailed Breakdown"):
#                     breakdown = result['breakdown']
                    
#                     # Display breakdown in a more organized way - using two rows of metrics
#                     st.write("#### Score breakdown:")
                    
#                     # First row - 4 metrics
#                     col1, col2, col3, col4 = st.columns(4)
                    
#                     with col1:
#                         st.metric(
#                             "Keywords", 
#                             f"{breakdown.get('keywords', 0)}/20"
#                         )
#                         st.progress(min(1.0, breakdown.get('keywords', 0)/20))
                        
#                     with col2:
#                         st.metric(
#                             "Sections", 
#                             f"{breakdown.get('sections', 0)}/20"
#                         )
#                         st.progress(min(1.0, breakdown.get('sections', 0)/20))
                        
#                     with col3:
#                         st.metric(
#                             "Experience", 
#                             f"{breakdown.get('experience', 0)}/15"
#                         )
#                         st.progress(min(1.0, breakdown.get('experience', 0)/15))
                        
#                     with col4:
#                         st.metric(
#                             "Education", 
#                             f"{breakdown.get('education', 0)}/10"
#                         )
#                         st.progress(min(1.0, breakdown.get('education', 0)/10))
                    
#                     # Second row - 3 metrics
#                     col1, col2, col3 = st.columns(3)
                    
#                     with col1:
#                         st.metric(
#                             "Achievements", 
#                             f"{breakdown.get('achievements', 0)}/15"
#                         )
#                         st.progress(min(1.0, breakdown.get('achievements', 0)/15))
                        
#                     with col2:
#                         st.metric(
#                             "Readability", 
#                             f"{breakdown.get('readability', 0)}/10"
#                         )
#                         st.progress(min(1.0, breakdown.get('readability', 0)/10))
                        
#                     with col3:
#                         custom_score = breakdown.get('custom', 0)
#                         st.metric(
#                             "Job Match" if job_desc else "Custom", 
#                             f"{custom_score}/10"
#                         )
#                         st.progress(min(1.0, custom_score/10))
                
#                 # Improvement suggestions
#                 st.subheader("💡 Improvement Suggestions")
#                 if result['feedback']:
#                     for suggestion in result['feedback']:
#                         st.write(f"- {suggestion}")
#                 else:
#                     st.write("No specific suggestions - your resume looks great!")
                
#                 # Parsed text
#                 with st.expander("📝 View Parsed Text"):
#                     st.text_area("Parsed Content", 
#                                value=result['parsed_text'],
#                                height=300,
#                                label_visibility="collapsed")
                
#                 # Download report
#                 report = generate_resume_report(result)
#                 st.download_button(
#                     label="📥 Download Analysis Report", 
#                     data=report,
#                     file_name="resume_analysis_report.txt",
#                     mime="text/plain",
#                     use_container_width=True
#                 )
                
#             except Exception as e:
#                 st.error(f"Unexpected error during analysis")
#                 with st.expander("View Error Details"):
#                     st.code(traceback.format_exc())

# def generate_resume_report(result):
#     """Generate downloadable report text"""
#     report = f"""RESUME ANALYSIS REPORT
# =======================

# Overall ATS Score: {result['percentage']}%

# SCORE BREAKDOWN:
# ----------------
# Keywords:       {result['breakdown'].get('keywords', 0)}/20
# Sections:       {result['breakdown'].get('sections', 0)}/20
# Experience:     {result['breakdown'].get('experience', 0)}/15
# Education:      {result['breakdown'].get('education', 0)}/10
# Achievements:   {result['breakdown'].get('achievements', 0)}/15
# Readability:    {result['breakdown'].get('readability', 0)}/10
# """
#     if result['breakdown'].get('custom', 0) > 0:
#         report += f"Job Match:      {result['breakdown'].get('custom', 0)}/10\n"

#     if 'feedback' in result and result['feedback']:
#         report += "\nIMPROVEMENT SUGGESTIONS:\n----------------\n"
#         report += "\n".join(f"- {suggestion}" for suggestion in result['feedback'])
    
#     if 'parsed_text' in result:
#         report += "\n\nPARSED TEXT EXCERPT:\n----------------\n"
#         excerpt = result['parsed_text'][:500]
#         report += excerpt + ("..." if len(result['parsed_text']) > 500 else "")
    
#     if result.get('warnings', []):
#         report += "\n\nPROCESSING NOTES:\n----------------\n"
#         report += "\n".join(f"- {warning}" for warning in result['warnings'])
    
#     return report

# def summary_section():
#     """Enhanced Summary section"""
#     st.subheader("📋 Overall Summary")
#     st.write("Your comprehensive job readiness evaluation")
    
#     # Initialize columns
#     col1, col2, col3 = st.columns(3)
    
#     # Interview Score
#     with col1:
#         if 'interview' in st.session_state:
#             interview_score = sum(r['score'] for r in st.session_state.interview['responses'])
#             max_interview = len(st.session_state.interview['responses']) * 6
#             st.metric("Interview Score", f"{interview_score}/{max_interview}")
#             st.progress(interview_score/max_interview)
#         else:
#             st.metric("Interview Score", "Not completed")
    
#     # Self Assessment
#     with col2:
#         if 'self_assessment_score' in st.session_state:
#             score = st.session_state.self_assessment_score
#             st.metric("Self Assessment", f"{score}/100")
#             st.progress(score/100)
#         else:
#             st.metric("Self Assessment", "Not completed")
    
#     # Resume Score
#     with col3:
#         if 'resume_score' in st.session_state:
#             score = st.session_state.resume_score
#             st.metric("Resume Score", f"{score}%")
#             st.progress(score/100)
#         else:
#             st.metric("Resume Score", "Not completed")
    
#     # Recommendations
#     st.subheader("📌 Recommended Next Steps")
    
#     recommendations = []
#     if 'resume_score' in st.session_state:
#         if st.session_state.resume_score < 70:
#             recommendations.append("✏️ Improve your resume based on the feedback provided")
    
#     if 'self_assessment_score' in st.session_state:
#         if st.session_state.self_assessment_score < 70:
#             recommendations.append("🧠 Focus on skill development in weaker areas")
    
#     if not recommendations:
#         recommendations.extend([
#             "✅ You're doing great! Keep refining your materials",
#             "🔍 Research target companies and roles",
#             "🤝 Network with professionals in your field"
#         ])
    
#     for rec in recommendations:
#         st.write(f"- {rec}")
    
#     if st.button("🔄 Reset All Progress", use_container_width=True):
#         st.session_state.clear()
#         st.rerun()

# def main():
#     """Main application with enhanced UI"""
#     st.title("💼 Job Readiness Assistant")
#     st.markdown("""
#     Welcome to your comprehensive job preparation toolkit. 
#     Use the sidebar to navigate between different assessment tools.
#     """)
    
#     # Sidebar navigation with icons
#     st.sidebar.title("🔍 Navigation")
#     sections = {
#         "📊 Self Assessment": self_assessment_section,
#         "🤖 AI Interview Bot": run_interview,
#         "📄 Resume Checker": resume_checker_section,
#         "📋 Summary": summary_section
#     }
#     choice = st.sidebar.radio(
#         "Go to", 
#         list(sections.keys()),
#         label_visibility="collapsed"
#     )
    
#     # Display selected section
#     sections[choice]()

# if __name__ == "__main__":
#     main()


# import streamlit as st
# from self_assessment.assessment import ask_questions, calculate_score, get_assessment_result
# from interview_bot.bot import run_interview
# from resume_checker.parser import parse_resume
# from resume_checker.ats_scoring import ats_score
# import traceback
# from datetime import datetime

# # Custom CSS for improved styling
# def inject_custom_css():
#     st.markdown("""
#     <style>
#         /* Main styling */
#         .stApp {
#             background-color: #f8f9fa;
#         }
#         .stButton>button {
#             border-radius: 8px;
#             padding: 10px 24px;
#             font-weight: 500;
#             transition: all 0.3s ease;
#         }
#         .stButton>button:hover {
#             transform: translateY(-2px);
#             box-shadow: 0 4px 8px rgba(0,0,0,0.1);
#         }
#         /* Card styling */
#         .card {
#             border-radius: 10px;
#             padding: 20px;
#             background: white;
#             box-shadow: 0 4px 6px rgba(0,0,0,0.05);
#             margin-bottom: 20px;
#         }
#         /* Progress bars */
#         .stProgress > div > div > div {
#             background-color: #4e79a7;
#         }
#         /* Metric cards */
#         [data-testid="metric-container"] {
#             border: 1px solid #e1e4e8;
#             border-radius: 10px;
#             padding: 15px;
#             background: white;
#         }
#         /* Sidebar */
#         [data-testid="stSidebar"] {
#             background: linear-gradient(180deg, #2c3e50, #3498db);
#             color: white;
#         }
#         .sidebar .sidebar-content {
#             color: white;
#         }
#         /* Custom success message */
#         .custom-success {
#             background-color: #d4edda;
#             color: #155724;
#             border-radius: 8px;
#             padding: 15px;
#             margin-bottom: 20px;
#         }
#     </style>
#     """, unsafe_allow_html=True)

# # Set page config
# st.set_page_config(
#     page_title="Job Readiness Assistant",
#     page_icon="💼",
#     layout="wide",
#     initial_sidebar_state="expanded"
# )

# # Inject custom CSS
# inject_custom_css()

# def generate_resume_report(result):
#     """Generate downloadable report text"""
#     report = f"""RESUME ANALYSIS REPORT
# =======================
# Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# Overall ATS Score: {result['percentage']}%

# SCORE BREAKDOWN:
# ----------------
# Keywords:       {result['breakdown'].get('keywords', 0)}/20
# Sections:       {result['breakdown'].get('sections', 0)}/20
# Experience:     {result['breakdown'].get('experience', 0)}/15
# Education:      {result['breakdown'].get('education', 0)}/10
# Achievements:   {result['breakdown'].get('achievements', 0)}/15
# Readability:    {result['breakdown'].get('readability', 0)}/10
# """
#     if result['breakdown'].get('custom', 0) > 0:
#         report += f"Job Match:      {result['breakdown'].get('custom', 0)}/10\n"

#     if 'feedback' in result and result['feedback']:
#         report += "\nIMPROVEMENT SUGGESTIONS:\n----------------\n"
#         report += "\n".join(f"- {suggestion}" for suggestion in result['feedback'])
    
#     if 'parsed_text' in result:
#         report += "\n\nPARSED TEXT EXCERPT:\n----------------\n"
#         excerpt = result['parsed_text'][:500]
#         report += excerpt + ("..." if len(result['parsed_text']) > 500 else "")
    
#     if result.get('warnings', []):
#         report += "\n\nPROCESSING NOTES:\n----------------\n"
#         report += "\n".join(f"- {warning}" for warning in result['warnings'])
    
#     return report

# def landing_page():
#     """Enhanced landing page with modern UI"""
#     st.title("🚀 Job Readiness Assistant")
#     st.markdown("""
#     <div class='card'>
#         <h3 style='color: #2c3e50;'>Your All-in-One Career Preparation Toolkit</h3>
#         <p>Get interview-ready with our comprehensive suite of tools designed to optimize your job search</p>
#     </div>
#     """, unsafe_allow_html=True)
    
#     # Hero section
#     col1, col2 = st.columns([2, 1])
#     with col1:
#         st.markdown("""
#         <div class='card'>
#             <h4 style='color: #2c3e50;'>Why Use This Tool?</h4>
#             <ul>
#                 <li>✅ Get <b>personalized feedback</b> on your job search materials</li>
#                 <li>✅ Identify and improve your <b>weak areas</b></li>
#                 <li>✅ Practice interviews <b>anytime, anywhere</b></li>
#                 <li>✅ Track your <b>progress over time</b></li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
        
#         if st.button("🌟 Get Started Now", use_container_width=True, type="primary"):
#             st.session_state.show_landing = False
#             st.rerun()
            
#     with col2:
#         st.image("https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80", 
#                 caption="Boost your career prospects")
    
#     # Features section
#     st.markdown("---")
#     st.subheader("✨ Key Features")
    
#     features = st.columns(3)
#     with features[0]:
#         st.markdown("""
#         <div class='card'>
#             <h4 style='color: #2c3e50;'>📄 Resume Analysis</h4>
#             <ul>
#                 <li>ATS compatibility scoring</li>
#                 <li>Detailed improvement suggestions</li>
#                 <li>Job description matching</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with features[1]:
#         st.markdown("""
#         <div class='card'>
#             <h4 style='color: #2c3e50;'>📊 Self-Assessment</h4>
#             <ul>
#                 <li>Skill evaluation</li>
#                 <li>Career readiness scoring</li>
#                 <li>Personalized recommendations</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with features[2]:
#         st.markdown("""
#         <div class='card'>
#             <h4 style='color: #2c3e50;'>💬 Mock Interviews</h4>
#             <ul>
#                 <li>Role-specific questions</li>
#                 <li>Performance scoring</li>
#                 <li>Response analysis</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     # Testimonials
#     st.markdown("---")
#     st.subheader("📣 What Users Say")
#     testimonial_cols = st.columns(2)
#     with testimonial_cols[0]:
#         st.markdown("""
#         <div class='card'>
#             <blockquote>
#                 "This tool helped me identify gaps in my resume I never noticed. 
#                 Landed 3 interviews in 2 weeks after making the suggested changes!"
#                 <footer style='text-align: right; font-weight: bold;'>— Sarah, Marketing Professional</footer>
#             </blockquote>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with testimonial_cols[1]:
#         st.markdown("""
#         <div class='card'>
#             <blockquote>
#                 "The mock interviews prepared me better than any book could. 
#                 I walked into my real interview with confidence!"
#                 <footer style='text-align: right; font-weight: bold;'>— James, Software Engineer</footer>
#             </blockquote>
#         </div>
#         """, unsafe_allow_html=True)

# def self_assessment_section():
#     """Enhanced Self Assessment section with improved UI"""
#     with st.container():
#         st.subheader("📊 Self Assessment")
#         with st.expander("ℹ️ About this section", expanded=False):
#             st.write("Evaluate your job readiness through carefully designed questions that assess key competencies.")
        
#         questions = ask_questions()
#         responses = []
        
#         for i, q in enumerate(questions):
#             with st.container():
#                 st.markdown(f"#### {i+1}. {q['question']}")
#                 response = st.radio(
#                     "Select your answer:",
#                     q['options'],
#                     key=f"self_assess_q{i}",
#                     index=None,
#                     horizontal=True
#                 )
#                 if response is None:
#                     st.warning("Please select an answer to proceed")
#                     return
#                 responses.append(q['scores'][q['options'].index(response)])
        
#         if st.button("📊 Calculate Score", use_container_width=True, type="primary"):
#             score = calculate_score(responses)
#             result = get_assessment_result(score)
#             st.session_state.self_assessment_score = score
            
#             st.markdown(f"""
#             <div class='custom-success'>
#                 <h3>Assessment Completed!</h3>
#             </div>
#             """, unsafe_allow_html=True)
            
#             col1, col2 = st.columns(2)
#             with col1:
#                 st.metric("Your Score", f"{score}/100")
#             with col2:
#                 st.metric("Result", result)
            
#             # Dynamic feedback based on score
#             st.subheader("📝 Personalized Feedback")
#             if score < 50:
#                 st.error("**Areas for Improvement**")
#                 st.write("""
#                 - Focus on skill development in your weak areas
#                 - Create a career development plan
#                 - Seek mentorship or training opportunities
#                 """)
#             elif score < 80:
#                 st.warning("**Good Progress**")
#                 st.write("""
#                 - Strengthen your interview skills
#                 - Refine your career goals
#                 - Expand your professional network
#                 """)
#             else:
#                 st.success("**Excellent Readiness**")
#                 st.write("""
#                 - Continue maintaining your skills
#                 - Consider leadership opportunities
#                 - Mentor others in your field
#                 """)

# def resume_checker_section():
#     """Enhanced Resume Checker with improved UI"""
#     with st.container():
#         st.subheader("📄 Resume Checker")
        
#         # Optional job description input
#         with st.expander("🔍 Add Job Description (Optional)", expanded=False):
#             job_description = st.text_area(
#                 "Paste the job description to get more targeted feedback",
#                 height=200,
#                 help="Adding a job description will help analyze how well your resume matches the specific role",
#                 placeholder="Paste the job description here..."
#             )
        
#         uploaded_file = st.file_uploader(
#             "Upload your resume (PDF)", 
#             type=["pdf"],
#             help="Upload your resume in PDF format for analysis"
#         )
        
#         if uploaded_file:
#             with st.spinner("🔍 Analyzing your resume..."):
#                 try:
#                     text = parse_resume(uploaded_file)
                    
#                     # Pass job description if provided
#                     job_desc = job_description if job_description and job_description.strip() else None
#                     result = ats_score(text, job_desc)
                    
#                     if 'error' in result:
#                         st.error(f"Analysis failed: {result['error']}")
#                         with st.expander("View Error Details"):
#                             st.text(result.get('parsed_text', ''))
#                         return
                    
#                     # Store results in session state
#                     st.session_state.resume_data = result
#                     st.session_state.resume_score = result['percentage']
                    
#                     # Display results
#                     st.markdown(f"""
#                     <div class='custom-success'>
#                         <h3>Analysis Complete! Score: {result['percentage']}%</h3>
#                     </div>
#                     """, unsafe_allow_html=True)
                    
#                     col1, col2 = st.columns(2)
#                     with col1:
#                         st.metric("ATS Score", f"{result['percentage']}%")
#                     with col2:
#                         st.progress(result['percentage']/100)
                    
#                     # Show warnings if any
#                     if result.get('warnings', []):
#                         with st.expander("⚠️ Processing Notes", expanded=False):
#                             for warning in result['warnings']:
#                                 st.warning(warning)
                    
#                     # Detailed breakdown
#                     with st.expander("📊 Detailed Breakdown", expanded=True):
#                         breakdown = result['breakdown']
                        
#                         st.write("#### Score breakdown:")
                        
#                         # First row - 4 metrics
#                         col1, col2, col3, col4 = st.columns(4)
                        
#                         with col1:
#                             st.metric(
#                                 "Keywords", 
#                                 f"{breakdown.get('keywords', 0)}/20",
#                                 help="Relevant industry keywords found"
#                             )
#                             st.progress(min(1.0, breakdown.get('keywords', 0)/20))
                            
#                         with col2:
#                             st.metric(
#                                 "Sections", 
#                                 f"{breakdown.get('sections', 0)}/20",
#                                 help="Proper resume sections (Experience, Education, etc.)"
#                             )
#                             st.progress(min(1.0, breakdown.get('sections', 0)/20))
                            
#                         with col3:
#                             st.metric(
#                                 "Experience", 
#                                 f"{breakdown.get('experience', 0)}/15",
#                                 help="Quality and relevance of work experience"
#                             )
#                             st.progress(min(1.0, breakdown.get('experience', 0)/15))
                            
#                         with col4:
#                             st.metric(
#                                 "Education", 
#                                 f"{breakdown.get('education', 0)}/10",
#                                 help="Education background relevance"
#                             )
#                             st.progress(min(1.0, breakdown.get('education', 0)/10))
                        
#                         # Second row - 3 metrics
#                         col1, col2, col3 = st.columns(3)
                        
#                         with col1:
#                             st.metric(
#                                 "Achievements", 
#                                 f"{breakdown.get('achievements', 0)}/15",
#                                 help="Measurable accomplishments and impact"
#                             )
#                             st.progress(min(1.0, breakdown.get('achievements', 0)/15))
                            
#                         with col2:
#                             st.metric(
#                                 "Readability", 
#                                 f"{breakdown.get('readability', 0)}/10",
#                                 help="Clarity and organization of content"
#                             )
#                             st.progress(min(1.0, breakdown.get('readability', 0)/10))
                            
#                         with col3:
#                             custom_score = breakdown.get('custom', 0)
#                             label = "Job Match" if job_desc else "Custom"
#                             st.metric(
#                                 label, 
#                                 f"{custom_score}/10",
#                                 help="Match with specific job description" if job_desc else "Custom scoring"
#                             )
#                             st.progress(min(1.0, custom_score/10))
                    
#                     # Improvement suggestions
#                     st.subheader("💡 Improvement Suggestions")
#                     if result['feedback']:
#                         for suggestion in result['feedback']:
#                             st.markdown(f"- {suggestion}")
#                     else:
#                         st.success("No specific suggestions - your resume looks great!")
                    
#                     # Parsed text
#                     with st.expander("📝 View Parsed Text", expanded=False):
#                         st.text_area("Parsed Content", 
#                                    value=result['parsed_text'],
#                                    height=300,
#                                    label_visibility="collapsed")
                    
#                     # Download report
#                     report = generate_resume_report(result)
#                     st.download_button(
#                         label="📥 Download Analysis Report", 
#                         data=report,
#                         file_name="resume_analysis_report.txt",
#                         mime="text/plain",
#                         use_container_width=True
#                     )
                    
#                 except Exception as e:
#                     st.error(f"Unexpected error during analysis")
#                     with st.expander("View Error Details"):
#                         st.code(traceback.format_exc())

# def summary_section():
#     """Enhanced Summary section with improved UI"""
#     with st.container():
#         st.subheader("📋 Overall Summary")
#         st.markdown("""
#         <div class='card'>
#             <p>Your comprehensive job readiness evaluation across all modules</p>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Initialize columns
#         col1, col2, col3 = st.columns(3)
        
#         # Interview Score
#         with col1:
#             if 'interview' in st.session_state:
#                 interview_score = sum(r['score'] for r in st.session_state.interview['responses'])
#                 max_interview = len(st.session_state.interview['responses']) * 6
#                 st.metric(
#                     "Interview Score", 
#                     f"{interview_score}/{max_interview}",
#                     help="Your performance in mock interviews"
#                 )
#                 st.progress(interview_score/max_interview)
#             else:
#                 st.metric("Interview Score", "Not completed")
        
#         # Self Assessment
#         with col2:
#             if 'self_assessment_score' in st.session_state:
#                 score = st.session_state.self_assessment_score
#                 st.metric(
#                     "Self Assessment", 
#                     f"{score}/100",
#                     help="Your skill assessment results"
#                 )
#                 st.progress(score/100)
#             else:
#                 st.metric("Self Assessment", "Not completed")
        
#         # Resume Score
#         with col3:
#             if 'resume_score' in st.session_state:
#                 score = st.session_state.resume_score
#                 st.metric(
#                     "Resume Score", 
#                     f"{score}%",
#                     help="Your resume's ATS compatibility"
#                 )
#                 st.progress(score/100)
#             else:
#                 st.metric("Resume Score", "Not completed")
        
#         # Recommendations
#         st.subheader("📌 Recommended Next Steps")
        
#         recommendations = []
#         if 'resume_score' in st.session_state:
#             if st.session_state.resume_score < 70:
#                 recommendations.append("✏️ Improve your resume based on the feedback provided")
        
#         if 'self_assessment_score' in st.session_state:
#             if st.session_state.self_assessment_score < 70:
#                 recommendations.append("🧠 Focus on skill development in weaker areas")
        
#         if not recommendations:
#             recommendations.extend([
#                 "✅ You're doing great! Keep refining your materials",
#                 "🔍 Research target companies and roles",
#                 "🤝 Network with professionals in your field"
#             ])
        
#         for rec in recommendations:
#             st.markdown(f"- {rec}")
        
#         if st.button("🔄 Reset All Progress", use_container_width=True):
#             st.session_state.clear()
#             st.rerun()

# def main():
#     """Main application with enhanced UI"""
#     # Initialize session state for landing page
#     if 'show_landing' not in st.session_state:
#         st.session_state.show_landing = True
    
#     # Show landing page or main app
#     if st.session_state.show_landing:
#         landing_page()
#     else:
#         # Main app header
#         st.markdown("""
#         <div style='background-color: #2c3e50; padding: 20px; border-radius: 10px; margin-bottom: 20px;'>
#             <h1 style='color: white; margin: 0;'>💼 Job Readiness Assistant</h1>
#             <p style='color: #ecf0f1; margin: 0;'>Your comprehensive job preparation toolkit</p>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Sidebar navigation with enhanced UI
#         with st.sidebar:
#             st.markdown("""
#             <div style='padding: 10px; border-radius: 10px; background-color: #3498db; margin-bottom: 20px;'>
#                 <h2 style='color: white; text-align: center;'>🔍 Navigation</h2>
#             </div>
#             """, unsafe_allow_html=True)
            
#             sections = {
#                 "📊 Self Assessment": self_assessment_section,
#                 "🤖 AI Interview Bot": run_interview,
#                 "📄 Resume Checker": resume_checker_section,
#                 "📋 Summary": summary_section
#             }
#             choice = st.radio(
#                 "Go to", 
#                 list(sections.keys()),
#                 label_visibility="collapsed"
#             )
            
#             st.markdown("---")
#             if st.button("🏠 Return to Home", use_container_width=True):
#                 st.session_state.show_landing = True
#                 st.rerun()
            
#             # Add a small footer
#             st.markdown("""
#             <div style='text-align: center; margin-top: 40px; font-size: 0.8em; color: #7f8c8d;'>
#                 Job Readiness Assistant v1.0
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Display selected section
#         sections[choice]()

# if __name__ == "__main__":
#     main()
import streamlit as st
from self_assessment.assessment import ask_questions, calculate_score, get_assessment_result
from interview_bot.bot import run_interview
from resume_checker.parser import parse_resume
from resume_checker.ats_scoring import ats_score
import traceback
from datetime import datetime

# Custom CSS for modern styling
def inject_custom_css():
    st.markdown("""
    <style>
        /* Main app styling */
        .stApp {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Headers */
        h1, h2, h3, h4, h5, h6 {
            color: #333333;
            font-weight: 600;
        }
        
        /* Buttons */
        .stButton>button {
            border-radius: 12px;
            padding: 12px 24px;
            font-weight: 600;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            border: none;
        }
        .stButton>button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
            opacity: 0.9;
        }
        
        /* Cards */
        .card {
            border-radius: 16px;
            padding: 24px;
            background: white;
            box-shadow: 0 8px 16px rgba(0,0,0,0.08);
            margin-bottom: 24px;
            border: 1px solid #e0e6ed;
            color: #333333;
        }
        
        /* Progress bars */
        .stProgress > div > div > div {
            background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%);
            border-radius: 8px;
        }
        
        /* Metrics */
        [data-testid="metric-container"] {
            border: 1px solid #e0e6ed;
            border-radius: 12px;
            padding: 20px;
            background: white;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        }
        
        /* Sidebar */
        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, #2c3e50 0%, #4ca1af 100%);
        }
        .sidebar .sidebar-content {
            color: white;
        }
        .sidebar .stRadio label {
            color: white;
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 8px;
            margin: 4px 0;
            transition: all 0.3s ease;
        }
        .sidebar .stRadio label:hover {
            background: rgba(255,255,255,0.1);
        }
        .sidebar .stRadio [aria-checked="true"] label {
            background: rgba(255,255,255,0.2);
            font-weight: 600;
        }
        
        /* Success messages */
        .custom-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
            border-left: 5px solid #28a745;
        }
        
        /* Error messages */
        .stAlert {
            border-radius: 12px;
        }
        
        /* Text inputs */
        .stTextArea textarea, .stTextInput input {
            border-radius: 12px;
            padding: 12px;
        }
        
        /* Expanders */
        .stExpander {
            border-radius: 12px;
            border: 1px solid #e0e6ed;
        }
        
        /* Radio buttons */
        .stRadio [role="radiogroup"] {
            gap: 12px;
        }
        .stRadio [role="radio"] {
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid #e0e6ed;
            background: white;
        }
        .stRadio [role="radio"][aria-checked="true"] {
            border: 1px solid #6a11cb;
            background: rgba(106, 17, 203, 0.1);
        }
        
        /* Fix flex display issues */
        div[style*='display: flex'] {
            display: flex !important;
            align-items: center !important;
        }
        
        /* Ensure text is visible with proper contrast */
        p, li, span {
            color: #333333;
        }
        
        /* Fix icon display */
        div[style*='justify-content: center'] span {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            text-align: center !important;
        }
    </style>
    """, unsafe_allow_html=True)

# Set page config
st.set_page_config(
    page_title="Job Readiness Assistant",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inject custom CSS
inject_custom_css()

def generate_resume_report(result):
    """Generate downloadable report text"""
    report = f"""RESUME ANALYSIS REPORT
=======================
Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Overall ATS Score: {result['percentage']}%

SCORE BREAKDOWN:
----------------
Keywords:       {result['breakdown'].get('keywords', 0)}/20
Sections:       {result['breakdown'].get('sections', 0)}/20
Experience:     {result['breakdown'].get('experience', 0)}/15
Education:      {result['breakdown'].get('education', 0)}/10
Achievements:   {result['breakdown'].get('achievements', 0)}/15
Readability:    {result['breakdown'].get('readability', 0)}/10
"""
    if result['breakdown'].get('custom', 0) > 0:
        report += f"Job Match:      {result['breakdown'].get('custom', 0)}/10\n"

    if 'feedback' in result and result['feedback']:
        report += "\nIMPROVEMENT SUGGESTIONS:\n----------------\n"
        report += "\n".join(f"- {suggestion}" for suggestion in result['feedback'])
    
    if 'parsed_text' in result:
        report += "\n\nPARSED TEXT EXCERPT:\n----------------\n"
        excerpt = result['parsed_text'][:500]
        report += excerpt + ("..." if len(result['parsed_text']) > 500 else "")
    
    if result.get('warnings', []):
        report += "\n\nPROCESSING NOTES:\n----------------\n"
        report += "\n".join(f"- {warning}" for warning in result['warnings'])
    
    return report

def landing_page():
    """Modern landing page with vibrant design and improved text visibility"""
    # Hero section with gradient background
    st.markdown("""
    <div style='background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); 
                padding: 40px; 
                border-radius: 16px; 
                margin-bottom: 32px;
                color: white;
                text-align: center;'>
        <h1 style='color: white; font-size: 2.5rem; margin-bottom: 1rem;'>🚀 Supercharge Your Job Search</h1>
        <p style='font-size: 1.2rem; color: white; margin-bottom: 0;'>Your all-in-one toolkit for resume optimization, skill assessment, and interview preparation</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Value proposition cards
    st.subheader("✨ Why Choose Our Tool?")
    cols = st.columns(3)
    with cols[0]:
        st.markdown("""
        <div class='card'>
            <div style='display: flex; align-items: center; margin-bottom: 16px;'>
                <div style='background: #6a11cb; width: 48px; height: 48px; border-radius: 12px; 
                            display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
                    <span style='color: white; font-size: 24px; line-height: 48px;'>📊</span>
                </div>
                <h3 style='margin: 0; color: #333333;'>Data-Driven</h3>
            </div>
            <p style='color: #333333;'>Get actionable insights based on real hiring data and ATS requirements</p>
        </div>
        """, unsafe_allow_html=True)
    
    with cols[1]:
        st.markdown("""
        <div class='card'>
            <div style='display: flex; align-items: center; margin-bottom: 16px;'>
                <div style='background: #2575fc; width: 48px; height: 48px; border-radius: 12px; 
                            display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
                    <span style='color: white; font-size: 24px; line-height: 48px;'>💡</span>
                </div>
                <h3 style='margin: 0; color: #333333;'>Personalized</h3>
            </div>
            <p style='color: #333333;'>Tailored recommendations based on your unique profile and goals</p>
        </div>
        """, unsafe_allow_html=True)
    
    with cols[2]:
        st.markdown("""
        <div class='card'>
            <div style='display: flex; align-items: center; margin-bottom: 16px;'>
                <div style='background: #00b09b; width: 48px; height: 48px; border-radius: 12px; 
                            display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
                    <span style='color: white; font-size: 24px; line-height: 48px;'>⚡</span>
                </div>
                <h3 style='margin: 0; color: #333333;'>Results-Oriented</h3>
            </div>
            <p style='color: #333333;'>Proven to help job seekers land more interviews and better offers</p>
        </div>
        """, unsafe_allow_html=True)
    
    # CTA Button
    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("🚀 Start Your Journey Now", use_container_width=True, type="primary"):
        st.session_state.show_landing = False
        st.rerun()
    
    # Features section
    st.markdown("<hr style='margin: 30px 0; border-color: #e0e6ed;'>", unsafe_allow_html=True)
    st.subheader("🔍 Key Features")
    
    features = st.columns(3)
    with features[0]:
        st.markdown("""
        <div class='card'>
            <h3 style='color: #6a11cb;'>Resume Analysis</h3>
            <ul style='padding-left: 20px;'>
                <li style='color: #333333;'>ATS compatibility scoring</li>
                <li style='color: #333333;'>Detailed improvement suggestions</li>
                <li style='color: #333333;'>Job description matching</li>
                <li style='color: #333333;'>Keyword optimization</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    with features[1]:
        st.markdown("""
        <div class='card'>
            <h3 style='color: #2575fc;'>Skill Assessment</h3>
            <ul style='padding-left: 20px;'>
                <li style='color: #333333;'>Comprehensive evaluation</li>
                <li style='color: #333333;'>Career readiness scoring</li>
                <li style='color: #333333;'>Personalized recommendations</li>
                <li style='color: #333333;'>Progress tracking</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    with features[2]:
        st.markdown("""
        <div class='card'>
            <h3 style='color: #00b09b;'>Mock Interviews</h3>
            <ul style='padding-left: 20px;'>
                <li style='color: #333333;'>Role-specific questions</li>
                <li style='color: #333333;'>Performance scoring</li>
                <li style='color: #333333;'>Response analysis</li>
                <li style='color: #333333;'>Confidence building</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
    
    # Testimonials with custom avatar divs (instead of external images)
    st.markdown("<hr style='margin: 30px 0; border-color: #e0e6ed;'>", unsafe_allow_html=True)
    st.subheader("💬 Success Stories")
    testimonials = st.columns(2)
    with testimonials[0]:
        st.markdown("""
        <div class='card'>
            <div style='display: flex; align-items: center; margin-bottom: 12px;'>
                <div style='width: 48px; height: 48px; border-radius: 50%; margin-right: 12px; 
                            background-color: #6a11cb; color: white; display: flex; 
                            align-items: center; justify-content: center; font-weight: bold;'>SJ</div>
                <div>
                    <h4 style='margin: 0; color: #333333;'>Sarah Johnson</h4>
                    <p style='margin: 0; color: #6c757d;'>Marketing Director</p>
                </div>
            </div>
            <p style='font-style: italic; color: #333333;'>"This tool helped me identify gaps in my resume I never noticed. Landed 3 interviews in 2 weeks after making the suggested changes!"</p>
            <div style='color: gold; font-size: 18px;'>★★★★★</div>
        </div>
        """, unsafe_allow_html=True)
    
    with testimonials[1]:
        st.markdown("""
        <div class='card'>
            <div style='display: flex; align-items: center; margin-bottom: 12px;'>
                <div style='width: 48px; height: 48px; border-radius: 50%; margin-right: 12px; 
                            background-color: #2575fc; color: white; display: flex; 
                            align-items: center; justify-content: center; font-weight: bold;'>JW</div>
                <div>
                    <h4 style='margin: 0; color: #333333;'>James Wilson</h4>
                    <p style='margin: 0; color: #6c757d;'>Software Engineer</p>
                </div>
            </div>
            <p style='font-style: italic; color: #333333;'>"The mock interviews prepared me better than any book could. I walked into my real interview with confidence!"</p>
            <div style='color: gold; font-size: 18px;'>★★★★★</div>
        </div>
        """, unsafe_allow_html=True)

    # Additional footer CTA
    st.markdown("<hr style='margin: 30px 0; border-color: #e0e6ed;'>", unsafe_allow_html=True)
    st.markdown("""
    <div style='text-align: center; padding: 20px;'>
        <h2 style='color: #333333;'>Ready to transform your job search?</h2>
        <p style='color: #333333; font-size: 18px;'>Join thousands of successful job seekers who have boosted their career prospects with our tools.</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Second CTA button
    if st.button("✨ Get Started Today", use_container_width=True, type="primary"):
        st.session_state.show_landing = False
        st.rerun()
def self_assessment_section():
    """Modern self-assessment section with improved UI"""
    with st.container():
        # Header with icon
        st.markdown("""
        <div style='display: flex; align-items: center; margin-bottom: 16px;'>
            <div style='background: #6a11cb; width: 48px; height: 48px; border-radius: 12px; 
                        display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
                <span style='color: white; font-size: 24px;'>📊</span>
            </div>
            <div>
                <h2 style='margin: 0;'>Skill Assessment</h2>
                <p style='margin: 0; color: #6c757d;'>Evaluate your job readiness across key competencies</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        with st.expander("ℹ️ About this assessment", expanded=False):
            st.write("This assessment evaluates your skills across various dimensions important for your career. Answer honestly to get the most accurate results.")
        
        questions = ask_questions()
        responses = []
        
        # Question cards
        for i, q in enumerate(questions):
            with st.container():
                st.markdown(f"""
                <div class='card'>
                    <h4>{i+1}. {q['question']}</h4>
                </div>
                """, unsafe_allow_html=True)
                
                response = st.radio(
                    "Select your answer:",
                    q['options'],
                    key=f"self_assess_q{i}",
                    index=None,
                    horizontal=True
                )
                if response is None:
                    st.warning("Please select an answer to proceed")
                    return
                responses.append(q['scores'][q['options'].index(response)])
        
        if st.button("📊 Calculate My Score", use_container_width=True, type="primary"):
            score = calculate_score(responses)
            result = get_assessment_result(score)
            st.session_state.self_assessment_score = score
            
            # Results card
            st.markdown(f"""
            <div class='custom-success'>
                <div style='display: flex; justify-content: space-between; align-items: center;'>
                    <h3 style='margin: 0;'>Assessment Complete!</h3>
                    <div style='background: #28a745; color: white; padding: 8px 16px; border-radius: 20px;'>
                        {score}/100
                    </div>
                </div>
                <p style='margin-bottom: 0;'>{result}</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Feedback section
            st.subheader("📝 Personalized Feedback")
            if score < 50:
                st.markdown("""
                <div class='card' style='border-left: 5px solid #dc3545;'>
                    <h4 style='color: #dc3545;'>Areas for Improvement</h4>
                    <ul>
                        <li>Focus on skill development in your weak areas</li>
                        <li>Create a career development plan</li>
                        <li>Seek mentorship or training opportunities</li>
                    </ul>
                </div>
                """, unsafe_allow_html=True)
            elif score < 80:
                st.markdown("""
                <div class='card' style='border-left: 5px solid #ffc107;'>
                    <h4 style='color: #ffc107;'>Good Progress</h4>
                    <ul>
                        <li>Strengthen your interview skills</li>
                        <li>Refine your career goals</li>
                        <li>Expand your professional network</li>
                    </ul>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class='card' style='border-left: 5px solid #28a745;'>
                    <h4 style='color: #28a745;'>Excellent Readiness</h4>
                    <ul>
                        <li>Continue maintaining your skills</li>
                        <li>Consider leadership opportunities</li>
                        <li>Mentor others in your field</li>
                    </ul>
                </div>
                """, unsafe_allow_html=True)

def resume_checker_section():
    """Modern resume checker with improved UI"""
    with st.container():
        # Header with icon
        st.markdown("""
        <div style='display: flex; align-items: center; margin-bottom: 16px;'>
            <div style='background: #2575fc; width: 48px; height: 48px; border-radius: 12px; 
                        display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
                <span style='color: white; font-size: 24px;'>📄</span>
            </div>
            <div>
                <h2 style='margin: 0;'>Resume Analysis</h2>
                <p style='margin: 0; color: #6c757d;'>Optimize your resume for Applicant Tracking Systems</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Optional job description input
        with st.expander("🔍 Add Job Description (Optional)", expanded=False):
            job_description = st.text_area(
                "Paste the job description to get more targeted feedback",
                height=200,
                help="Adding a job description will help analyze how well your resume matches the specific role",
                placeholder="Paste the job description here..."
            )
        
        # File uploader with custom styling
        uploaded_file = st.file_uploader(
            "Upload your resume (PDF)", 
            type=["pdf"],
            help="Upload your resume in PDF format for analysis",
            label_visibility="visible"
        )
        
        if uploaded_file:
            with st.spinner("🔍 Analyzing your resume..."):
                try:
                    text = parse_resume(uploaded_file)
                    
                    # Pass job description if provided
                    job_desc = job_description if job_description and job_description.strip() else None
                    result = ats_score(text, job_desc)
                    
                    if 'error' in result:
                        st.error(f"Analysis failed: {result['error']}")
                        with st.expander("View Error Details"):
                            st.text(result.get('parsed_text', ''))
                        return
                    
                    # Store results in session state
                    st.session_state.resume_data = result
                    st.session_state.resume_score = result['percentage']
                    
                    # Results header
                    st.markdown(f"""
                    <div class='custom-success'>
                        <div style='display: flex; justify-content: space-between; align-items: center;'>
                            <h3 style='margin: 0;'>Analysis Complete!</h3>
                            <div style='background: #28a745; color: white; padding: 8px 16px; border-radius: 20px;'>
                                {result['percentage']}%
                            </div>
                        </div>
                        <p style='margin-bottom: 0;'>Your resume's ATS compatibility score</p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    # Score visualization
                    col1, col2 = st.columns([1, 3])
                    with col1:
                        st.metric("ATS Score", f"{result['percentage']}%")
                    with col2:
                        st.progress(result['percentage']/100)
                    
                    # Show warnings if any
                    if result.get('warnings', []):
                        with st.expander("⚠️ Processing Notes", expanded=False):
                            for warning in result['warnings']:
                                st.warning(warning)
                    
                    # Detailed breakdown
                    with st.expander("📊 Detailed Breakdown", expanded=True):
                        breakdown = result['breakdown']
                        
                        st.write("#### Score Components:")
                        
                        # First row - 4 metrics
                        col1, col2, col3, col4 = st.columns(4)
                        
                        with col1:
                            st.metric(
                                "Keywords", 
                                f"{breakdown.get('keywords', 0)}/20",
                                help="Relevant industry keywords found",
                                delta_color="off"
                            )
                            st.progress(min(1.0, breakdown.get('keywords', 0)/20))
                            
                        with col2:
                            st.metric(
                                "Sections", 
                                f"{breakdown.get('sections', 0)}/20",
                                help="Proper resume sections (Experience, Education, etc.)",
                                delta_color="off"
                            )
                            st.progress(min(1.0, breakdown.get('sections', 0)/20))
                            
                        with col3:
                            st.metric(
                                "Experience", 
                                f"{breakdown.get('experience', 0)}/15",
                                help="Quality and relevance of work experience",
                                delta_color="off"
                            )
                            st.progress(min(1.0, breakdown.get('experience', 0)/15))
                            
                        with col4:
                            st.metric(
                                "Education", 
                                f"{breakdown.get('education', 0)}/10",
                                help="Education background relevance",
                                delta_color="off"
                            )
                            st.progress(min(1.0, breakdown.get('education', 0)/10))
                        
                        # Second row - 3 metrics
                        col1, col2, col3 = st.columns(3)
                        
                        with col1:
                            st.metric(
                                "Achievements", 
                                f"{breakdown.get('achievements', 0)}/15",
                                help="Measurable accomplishments and impact",
                                delta_color="off"
                            )
                            st.progress(min(1.0, breakdown.get('achievements', 0)/15))
                            
                        with col2:
                            st.metric(
                                "Readability", 
                                f"{breakdown.get('readability', 0)}/10",
                                help="Clarity and organization of content",
                                delta_color="off"
                            )
                            st.progress(min(1.0, breakdown.get('readability', 0)/10))
                            
                        with col3:
                            custom_score = breakdown.get('custom', 0)
                            label = "Job Match" if job_desc else "Custom"
                            st.metric(
                                label, 
                                f"{custom_score}/10",
                                help="Match with specific job description" if job_desc else "Custom scoring",
                                delta_color="off"
                            )
                            st.progress(min(1.0, custom_score/10))
                    
                    # Improvement suggestions
                    st.subheader("💡 Improvement Suggestions")
                    if result['feedback']:
                        st.markdown("""
                        <div class='card'>
                            <ul style='padding-left: 20px; margin-bottom: 0;'>
                        """ + "\n".join([f"<li>{suggestion}</li>" for suggestion in result['feedback']]) + """
                            </ul>
                        </div>
                        """, unsafe_allow_html=True)
                    else:
                        st.success("No specific suggestions - your resume looks great!")
                    
                    # Parsed text
                    with st.expander("📝 View Parsed Text", expanded=False):
                        st.text_area("Parsed Content", 
                                   value=result['parsed_text'],
                                   height=300,
                                   label_visibility="collapsed")
                    
                    # Download report
                    report = generate_resume_report(result)
                    st.download_button(
                        label="📥 Download Full Analysis Report", 
                        data=report,
                        file_name="resume_analysis_report.txt",
                        mime="text/plain",
                        use_container_width=True,
                        type="primary"
                    )
                    
                except Exception as e:
                    st.error(f"Unexpected error during analysis")
                    with st.expander("View Error Details"):
                        st.code(traceback.format_exc())

def summary_section():
    """Modern summary section with improved UI"""
    with st.container():
        # Header with icon
        st.markdown("""
        <div style='display: flex; align-items: center; margin-bottom: 16px;'>
            <div style='background: #00b09b; width: 48px; height: 48px; border-radius: 12px; 
                        display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
                <span style='color: white; font-size: 24px;'>📋</span>
            </div>
            <div>
                <h2 style='margin: 0;'>Your Progress Summary</h2>
                <p style='margin: 0; color: #6c757d;'>Comprehensive evaluation across all modules</p>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Metrics cards
        st.markdown("""
        <div class='card'>
            <h4 style='margin-top: 0;'>Your Scores</h4>
            <div style='display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;'>
        """, unsafe_allow_html=True)
        
        # Interview Score
        if 'interview' in st.session_state:
            interview_score = sum(r['score'] for r in st.session_state.interview['responses'])
            max_interview = len(st.session_state.interview['responses']) * 6
            st.markdown(f"""
            <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
                <h5 style='margin: 0 0 8px 0;'>Interview</h5>
                <h3 style='margin: 0;'>{interview_score}/{max_interview}</h3>
                <div style='margin-top: 8px;'>{st.progress(interview_score/max_interview)}</div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
                <h5 style='margin: 0 0 8px 0;'>Interview</h5>
                <p style='margin: 0; color: #6c757d;'>Not completed</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Self Assessment
        if 'self_assessment_score' in st.session_state:
            score = st.session_state.self_assessment_score
            st.markdown(f"""
            <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
                <h5 style='margin: 0 0 8px 0;'>Self Assessment</h5>
                <h3 style='margin: 0;'>{score}/100</h3>
                <div style='margin-top: 8px;'>{st.progress(score/100)}</div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
                <h5 style='margin: 0 0 8px 0;'>Self Assessment</h5>
                <p style='margin: 0; color: #6c757d;'>Not completed</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Resume Score
        if 'resume_score' in st.session_state:
            score = st.session_state.resume_score
            st.markdown(f"""
            <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
                <h5 style='margin: 0 0 8px 0;'>Resume</h5>
                <h3 style='margin: 0;'>{score}%</h3>
                <div style='margin-top: 8px;'>{st.progress(score/100)}</div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
                <h5 style='margin: 0 0 8px 0;'>Resume</h5>
                <p style='margin: 0; color: #000;'>Not completed</p>
            </div>
            """, unsafe_allow_html=True)
        
        st.markdown("</div></div>", unsafe_allow_html=True)
        
        # Recommendations
        st.subheader("📌 Recommended Next Steps")
        
        recommendations = []
        if 'resume_score' in st.session_state:
            if st.session_state.resume_score < 70:
                recommendations.append("✏️ Improve your resume based on the feedback provided")
        
        if 'self_assessment_score' in st.session_state:
            if st.session_state.self_assessment_score < 70:
                recommendations.append("🧠 Focus on skill development in weaker areas")
        
        if not recommendations:
            recommendations.extend([
                "✅ You're doing great! Keep refining your materials",
                "🔍 Research target companies and roles",
                "🤝 Network with professionals in your field"
            ])
        
        st.markdown("""
        <div class='card'>
            <ul style='padding-left: 20px; margin-bottom: 0;'>
        """ + "\n".join([f"<li>{rec}</li>" for rec in recommendations]) + """
            </ul>
        </div>
        """, unsafe_allow_html=True)
        
        if st.button("🔄 Reset All Progress", use_container_width=True):
            st.session_state.clear()
            st.rerun()

def main():
    """Main application with enhanced UI"""
    # Initialize session state for landing page
    if 'show_landing' not in st.session_state:
        st.session_state.show_landing = True
    
    # Show landing page or main app
    if st.session_state.show_landing:
        landing_page()
    else:
        # Main app header with gradient
        st.markdown("""
        <div style='background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); 
                    padding: 24px; 
                    border-radius: 16px; 
                    margin-bottom: 24px;
                    color: white;'>
            <h1 style='color: white; margin: 0;'>💼 Job Readiness Assistant</h1>
            <p style='color: #000; margin: 0;'>Your comprehensive job preparation toolkit</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Sidebar navigation with enhanced UI
        with st.sidebar:
            st.markdown("""
            <div style='padding: 16px; border-radius: 16px; background: linear-gradient(135deg, #2c3e50 0%, #4ca1af 100%); 
                        margin-bottom: 24px; color: white;'>
                <h2 style='color: white; text-align: center; margin: 0;'>🔍 Navigation</h2>
            </div>
            """, unsafe_allow_html=True)
            
            sections = {
                "📊 Self Assessment": self_assessment_section,
                "🤖 AI Interview Bot": run_interview,
                "📄 Resume Checker": resume_checker_section,
                "📋 Summary": summary_section
            }
            choice = st.radio(
                "Go to", 
                list(sections.keys()),
                label_visibility="collapsed"
            )
            
            st.markdown("---")
            if st.button("🏠 Return to Home", use_container_width=True):
                st.session_state.show_landing = True
                st.rerun()
            
            # Add a small footer
            st.markdown("""
            <div style='text-align: center; margin-top: 40px;'>
                <p style='font-size: 0.8em; color: #000; margin-bottom: 8px;'>
                    Job Readiness Assistant v2.0
                </p>
                <p style='font-size: 0.7em; color: #000; margin: 0;'>
                    © 2023 CareerPrep Tools
                </p>
            </div>
            """, unsafe_allow_html=True)
        
        # Display selected section
        sections[choice]()

if __name__ == "__main__":
    main()

# import streamlit as st
# from self_assessment.assessment import ask_questions, calculate_score, get_assessment_result
# from interview_bot.bot import run_interview
# from resume_checker.parser import parse_resume
# from resume_checker.ats_scoring import ats_score
# import traceback
# from datetime import datetime

# # Custom CSS for modern styling
# def inject_custom_css():
#     st.markdown("""
#     <style>
#         /* Main app styling */
#         .stApp {
#             background-color: #f5f7fa;
#             font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
#         }
        
#         /* Headers */
#         h1, h2, h3, h4, h5, h6 {
#             color: #2d3436;
#             font-weight: 600;
#         }
        
#         /* Buttons */
#         .stButton>button {
#             border-radius: 12px;
#             padding: 12px 24px;
#             font-weight: 600;
#             transition: all 0.3s ease;
#             background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
#             color: white;
#             border: none;
#         }
#         .stButton>button:hover {
#             transform: translateY(-2px);
#             box-shadow: 0 6px 12px rgba(0,0,0,0.15);
#             opacity: 0.9;
#         }
        
#         /* Cards */
#         .card {
#             border-radius: 16px;
#             padding: 24px;
#             background: white;
#             box-shadow: 0 8px 16px rgba(0,0,0,0.08);
#             margin-bottom: 24px;
#             border: 1px solid #e0e6ed;
#         }
        
#         /* Progress bars */
#         .stProgress > div > div > div {
#             background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%);
#             border-radius: 8px;
#         }
        
#         /* Metrics */
#         [data-testid="metric-container"] {
#             border: 1px solid #e0e6ed;
#             border-radius: 12px;
#             padding: 20px;
#             background: white;
#             box-shadow: 0 4px 8px rgba(0,0,0,0.05);
#         }
        
#         /* Sidebar */
#         [data-testid="stSidebar"] {
#             background: linear-gradient(180deg, #2c3e50 0%, #4ca1af 100%);
#         }
#         .sidebar .sidebar-content {
#             color: white !important;
#         }
#         .sidebar .stRadio label {
#             color: white !important;
#             font-weight: 500;
#             padding: 8px 12px;
#             border-radius: 8px;
#             margin: 4px 0;
#             transition: all 0.3s ease;
#         }
#         .sidebar .stRadio label:hover {
#             background: rgba(255,255,255,0.1);
#         }
#         .sidebar .stRadio [aria-checked="true"] label {
#             background: rgba(255,255,255,0.2);
#             font-weight: 600;
#         }
        
#         /* Success messages */
#         .custom-success {
#             background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
#             color: #155724;
#             border-radius: 12px;
#             padding: 20px;
#             margin-bottom: 24px;
#             border-left: 5px solid #28a745;
#         }
        
#         /* Error messages */
#         .stAlert {
#             border-radius: 12px;
#         }
        
#         /* Text inputs */
#         .stTextArea textarea, .stTextInput input {
#             border-radius: 12px;
#             padding: 12px;
#         }
        
#         /* Expanders */
#         .stExpander {
#             border-radius: 12px;
#             border: 1px solid #e0e6ed;
#         }
        
#         /* Radio buttons */
#         .stRadio [role="radiogroup"] {
#             gap: 12px;
#         }
#         .stRadio [role="radio"] {
#             padding: 12px 16px;
#             border-radius: 12px;
#             border: 1px solid #e0e6ed;
#             background: white;
#         }
#         .stRadio [role="radio"][aria-checked="true"] {
#             border: 1px solid #6a11cb;
#             background: rgba(106, 17, 203, 0.1);
#         }
        
#         /* Fix for sidebar text color */
#         .stSidebar .stRadio label, 
#         .stSidebar .stMarkdown, 
#         .stSidebar .stText {
#             color: white !important;
#         }
        
#         /* Fix for dark text in cards */
#         .card h1, .card h2, .card h3, .card h4, .card h5, .card h6,
#         .card p, .card li {
#             color: #2d3436 !important;
#         }
#     </style>
#     """, unsafe_allow_html=True)

# # Set page config
# st.set_page_config(
#     page_title="Job Readiness Assistant",
#     page_icon="💼",
#     layout="wide",
#     initial_sidebar_state="expanded"
# )

# # Inject custom CSS
# inject_custom_css()

# def generate_resume_report(result):
#     """Generate downloadable report text"""
#     report = f"""RESUME ANALYSIS REPORT
# =======================
# Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# Overall ATS Score: {result['percentage']}%

# SCORE BREAKDOWN:
# ----------------
# Keywords:       {result['breakdown'].get('keywords', 0)}/20
# Sections:       {result['breakdown'].get('sections', 0)}/20
# Experience:     {result['breakdown'].get('experience', 0)}/15
# Education:      {result['breakdown'].get('education', 0)}/10
# Achievements:   {result['breakdown'].get('achievements', 0)}/15
# Readability:    {result['breakdown'].get('readability', 0)}/10
# """
#     if result['breakdown'].get('custom', 0) > 0:
#         report += f"Job Match:      {result['breakdown'].get('custom', 0)}/10\n"

#     if 'feedback' in result and result['feedback']:
#         report += "\nIMPROVEMENT SUGGESTIONS:\n----------------\n"
#         report += "\n".join(f"- {suggestion}" for suggestion in result['feedback'])
    
#     if 'parsed_text' in result:
#         report += "\n\nPARSED TEXT EXCERPT:\n----------------\n"
#         excerpt = result['parsed_text'][:500]
#         report += excerpt + ("..." if len(result['parsed_text']) > 500 else "")
    
#     if result.get('warnings', []):
#         report += "\n\nPROCESSING NOTES:\n----------------\n"
#         report += "\n".join(f"- {warning}" for warning in result['warnings'])
    
#     return report

# def landing_page():
#     """Modern landing page with vibrant design"""
#     # Hero section with gradient background
#     st.markdown("""
#     <div style='background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); 
#                 padding: 40px; 
#                 border-radius: 16px; 
#                 margin-bottom: 32px;
#                 color: white;'>
#         <h1 style='color: white;'>🚀 Supercharge Your Job Search</h1>
#         <p style='font-size: 18px; color: white;'>Your all-in-one toolkit for resume optimization, skill assessment, and interview preparation</p>
#     </div>
#     """, unsafe_allow_html=True)
    
#     # Value proposition cards
#     st.subheader("✨ Why Choose Our Tool?")
#     cols = st.columns(3)
#     with cols[0]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#                 <div style='background: #6a11cb; width: 48px; height: 48px; border-radius: 12px; 
#                             display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
#                     <span style='color: white; font-size: 24px;'>📊</span>
#                 </div>
#                 <h3 style='margin: 0; color: #2d3436;'>Data-Driven</h3>
#             </div>
#             <p style='color: #2d3436;'>Get actionable insights based on real hiring data and ATS requirements</p>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with cols[1]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#                 <div style='background: #2575fc; width: 48px; height: 48px; border-radius: 12px; 
#                             display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
#                     <span style='color: white; font-size: 24px;'>💡</span>
#                 </div>
#                 <h3 style='margin: 0; color: #2d3436;'>Personalized</h3>
#             </div>
#             <p style='color: #2d3436;'>Tailored recommendations based on your unique profile and goals</p>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with cols[2]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#                 <div style='background: #00b09b; width: 48px; height: 48px; border-radius: 12px; 
#                             display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
#                     <span style='color: white; font-size: 24px;'>⚡</span>
#                 </div>
#                 <h3 style='margin: 0; color: #2d3436;'>Results-Oriented</h3>
#             </div>
#             <p style='color: #2d3436;'>Proven to help job seekers land more interviews and better offers</p>
#         </div>
#         """, unsafe_allow_html=True)
    
#     # CTA Button
#     st.markdown("<br>", unsafe_allow_html=True)
#     if st.button("🚀 Start Your Journey Now", use_container_width=True, type="primary"):
#         st.session_state.show_landing = False
#         st.rerun()
    
#     # Features section
#     st.markdown("---")
#     st.subheader("🔍 Key Features")
    
#     features = st.columns(3)
#     with features[0]:
#         st.markdown("""
#         <div class='card'>
#             <h3 style='color: #6a11cb;'>Resume Analysis</h3>
#             <ul style='padding-left: 20px;'>
#                 <li style='color: #2d3436;'>ATS compatibility scoring</li>
#                 <li style='color: #2d3436;'>Detailed improvement suggestions</li>
#                 <li style='color: #2d3436;'>Job description matching</li>
#                 <li style='color: #2d3436;'>Keyword optimization</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with features[1]:
#         st.markdown("""
#         <div class='card'>
#             <h3 style='color: #2575fc;'>Skill Assessment</h3>
#             <ul style='padding-left: 20px;'>
#                 <li style='color: #2d3436;'>Comprehensive evaluation</li>
#                 <li style='color: #2d3436;'>Career readiness scoring</li>
#                 <li style='color: #2d3436;'>Personalized recommendations</li>
#                 <li style='color: #2d3436;'>Progress tracking</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with features[2]:
#         st.markdown("""
#         <div class='card'>
#             <h3 style='color: #00b09b;'>Mock Interviews</h3>
#             <ul style='padding-left: 20px;'>
#                 <li style='color: #2d3436;'>Role-specific questions</li>
#                 <li style='color: #2d3436;'>Performance scoring</li>
#                 <li style='color: #2d3436;'>Response analysis</li>
#                 <li style='color: #2d3436;'>Confidence building</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     # Testimonials with avatars
#     st.markdown("---")
#     st.subheader("💬 Success Stories")
#     testimonials = st.columns(2)
#     with testimonials[0]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 12px;'>
#                 <img src='https://randomuser.me/api/portraits/women/44.jpg' style='width: 48px; height: 48px; border-radius: 50%; margin-right: 12px;'>
#                 <div>
#                     <h4 style='margin: 0; color: #2d3436;'>Sarah Johnson</h4>
#                     <p style='margin: 0; color: #6c757d;'>Marketing Director</p>
#                 </div>
#             </div>
#             <p style='font-style: italic; color: #2d3436;'>"This tool helped me identify gaps in my resume I never noticed. Landed 3 interviews in 2 weeks after making the suggested changes!"</p>
#             <div style='color: gold; font-size: 18px;'>★★★★★</div>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with testimonials[1]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 12px;'>
#                 <img src='https://randomuser.me/api/portraits/men/32.jpg' style='width: 48px; height: 48px; border-radius: 50%; margin-right: 12px;'>
#                 <div>
#                     <h4 style='margin: 0; color: #2d3436;'>James Wilson</h4>
#                     <p style='margin: 0; color: #6c757d;'>Software Engineer</p>
#                 </div>
#             </div>
#             <p style='font-style: italic; color: #2d3436;'>"The mock interviews prepared me better than any book could. I walked into my real interview with confidence!"</p>
#             <div style='color: gold; font-size: 18px;'>★★★★★</div>
#         </div>
#         """, unsafe_allow_html=True)

# def self_assessment_section():
#     """Modern self-assessment section with improved UI"""
#     with st.container():
#         # Header with icon
#         st.markdown("""
#         <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#             <div style='background: #6a11cb; width: 48px; height: 48px; border-radius: 12px; 
#                         display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
#                 <span style='color: white; font-size: 24px;'>📊</span>
#             </div>
#             <div>
#                 <h2 style='margin: 0; color: #2d3436;'>Skill Assessment</h2>
#                 <p style='margin: 0; color: #6c757d;'>Evaluate your job readiness across key competencies</p>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)
        
#         with st.expander("ℹ️ About this assessment", expanded=False):
#             st.write("This assessment evaluates your skills across various dimensions important for your career. Answer honestly to get the most accurate results.")
        
#         questions = ask_questions()
#         responses = []
        
#         # Question cards
#         for i, q in enumerate(questions):
#             with st.container():
#                 st.markdown(f"""
#                 <div class='card'>
#                     <h4 style='color: #2d3436;'>{i+1}. {q['question']}</h4>
#                 </div>
#                 """, unsafe_allow_html=True)
                
#                 response = st.radio(
#                     "Select your answer:",
#                     q['options'],
#                     key=f"self_assess_q{i}",
#                     index=None,
#                     horizontal=True
#                 )
#                 if response is None:
#                     st.warning("Please select an answer to proceed")
#                     return
#                 responses.append(q['scores'][q['options'].index(response)])
        
#         if st.button("📊 Calculate My Score", use_container_width=True, type="primary"):
#             score = calculate_score(responses)
#             result = get_assessment_result(score)
#             st.session_state.self_assessment_score = score
            
#             # Results card
#             st.markdown(f"""
#             <div class='custom-success'>
#                 <div style='display: flex; justify-content: space-between; align-items: center;'>
#                     <h3 style='margin: 0; color: #155724;'>Assessment Complete!</h3>
#                     <div style='background: #28a745; color: white; padding: 8px 16px; border-radius: 20px;'>
#                         {score}/100
#                     </div>
#                 </div>
#                 <p style='margin-bottom: 0; color: #155724;'>{result}</p>
#             </div>
#             """, unsafe_allow_html=True)
            
#             # Feedback section
#             st.subheader("📝 Personalized Feedback")
#             if score < 50:
#                 st.markdown("""
#                 <div class='card' style='border-left: 5px solid #dc3545;'>
#                     <h4 style='color: #dc3545;'>Areas for Improvement</h4>
#                     <ul>
#                         <li style='color: #2d3436;'>Focus on skill development in your weak areas</li>
#                         <li style='color: #2d3436;'>Create a career development plan</li>
#                         <li style='color: #2d3436;'>Seek mentorship or training opportunities</li>
#                     </ul>
#                 </div>
#                 """, unsafe_allow_html=True)
#             elif score < 80:
#                 st.markdown("""
#                 <div class='card' style='border-left: 5px solid #ffc107;'>
#                     <h4 style='color: #ffc107;'>Good Progress</h4>
#                     <ul>
#                         <li style='color: #2d3436;'>Strengthen your interview skills</li>
#                         <li style='color: #2d3436;'>Refine your career goals</li>
#                         <li style='color: #2d3436;'>Expand your professional network</li>
#                     </ul>
#                 </div>
#                 """, unsafe_allow_html=True)
#             else:
#                 st.markdown("""
#                 <div class='card' style='border-left: 5px solid #28a745;'>
#                     <h4 style='color: #28a745;'>Excellent Readiness</h4>
#                     <ul>
#                         <li style='color: #2d3436;'>Continue maintaining your skills</li>
#                         <li style='color: #2d3436;'>Consider leadership opportunities</li>
#                         <li style='color: #2d3436;'>Mentor others in your field</li>
#                     </ul>
#                 </div>
#                 """, unsafe_allow_html=True)

# def resume_checker_section():
#     """Modern resume checker with improved UI"""
#     with st.container():
#         # Header with icon
#         st.markdown("""
#         <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#             <div style='background: #2575fc; width: 48px; height: 48px; border-radius: 12px; 
#                         display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
#                 <span style='color: white; font-size: 24px;'>📄</span>
#             </div>
#             <div>
#                 <h2 style='margin: 0; color: #2d3436;'>Resume Analysis</h2>
#                 <p style='margin: 0; color: #6c757d;'>Optimize your resume for Applicant Tracking Systems</p>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Optional job description input
#         with st.expander("🔍 Add Job Description (Optional)", expanded=False):
#             job_description = st.text_area(
#                 "Paste the job description to get more targeted feedback",
#                 height=200,
#                 help="Adding a job description will help analyze how well your resume matches the specific role",
#                 placeholder="Paste the job description here..."
#             )
        
#         # File uploader with custom styling
#         uploaded_file = st.file_uploader(
#             "Upload your resume (PDF)", 
#             type=["pdf"],
#             help="Upload your resume in PDF format for analysis",
#             label_visibility="visible"
#         )
        
#         if uploaded_file:
#             with st.spinner("🔍 Analyzing your resume..."):
#                 try:
#                     text = parse_resume(uploaded_file)
                    
#                     # Pass job description if provided
#                     job_desc = job_description if job_description and job_description.strip() else None
#                     result = ats_score(text, job_desc)
                    
#                     if 'error' in result:
#                         st.error(f"Analysis failed: {result['error']}")
#                         with st.expander("View Error Details"):
#                             st.text(result.get('parsed_text', ''))
#                         return
                    
#                     # Store results in session state
#                     st.session_state.resume_data = result
#                     st.session_state.resume_score = result['percentage']
                    
#                     # Results header
#                     st.markdown(f"""
#                     <div class='custom-success'>
#                         <div style='display: flex; justify-content: space-between; align-items: center;'>
#                             <h3 style='margin: 0; color: #155724;'>Analysis Complete!</h3>
#                             <div style='background: #28a745; color: white; padding: 8px 16px; border-radius: 20px;'>
#                                 {result['percentage']}%
#                             </div>
#                         </div>
#                         <p style='margin-bottom: 0; color: #155724;'>Your resume's ATS compatibility score</p>
#                     </div>
#                     """, unsafe_allow_html=True)
                    
#                     # Score visualization
#                     col1, col2 = st.columns([1, 3])
#                     with col1:
#                         st.metric("ATS Score", f"{result['percentage']}%")
#                     with col2:
#                         st.progress(result['percentage']/100)
                    
#                     # Show warnings if any
#                     if result.get('warnings', []):
#                         with st.expander("⚠️ Processing Notes", expanded=False):
#                             for warning in result['warnings']:
#                                 st.warning(warning)
                    
#                     # Detailed breakdown
#                     with st.expander("📊 Detailed Breakdown", expanded=True):
#                         breakdown = result['breakdown']
                        
#                         st.write("#### Score Components:")
                        
#                         # First row - 4 metrics
#                         col1, col2, col3, col4 = st.columns(4)
                        
#                         with col1:
#                             st.metric(
#                                 "Keywords", 
#                                 f"{breakdown.get('keywords', 0)}/20",
#                                 help="Relevant industry keywords found",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('keywords', 0)/20))
                            
#                         with col2:
#                             st.metric(
#                                 "Sections", 
#                                 f"{breakdown.get('sections', 0)}/20",
#                                 help="Proper resume sections (Experience, Education, etc.)",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('sections', 0)/20))
                            
#                         with col3:
#                             st.metric(
#                                 "Experience", 
#                                 f"{breakdown.get('experience', 0)}/15",
#                                 help="Quality and relevance of work experience",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('experience', 0)/15))
                            
#                         with col4:
#                             st.metric(
#                                 "Education", 
#                                 f"{breakdown.get('education', 0)}/10",
#                                 help="Education background relevance",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('education', 0)/10))
                        
#                         # Second row - 3 metrics
#                         col1, col2, col3 = st.columns(3)
                        
#                         with col1:
#                             st.metric(
#                                 "Achievements", 
#                                 f"{breakdown.get('achievements', 0)}/15",
#                                 help="Measurable accomplishments and impact",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('achievements', 0)/15))
                            
#                         with col2:
#                             st.metric(
#                                 "Readability", 
#                                 f"{breakdown.get('readability', 0)}/10",
#                                 help="Clarity and organization of content",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('readability', 0)/10))
                            
#                         with col3:
#                             custom_score = breakdown.get('custom', 0)
#                             label = "Job Match" if job_desc else "Custom"
#                             st.metric(
#                                 label, 
#                                 f"{custom_score}/10",
#                                 help="Match with specific job description" if job_desc else "Custom scoring",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, custom_score/10))
                    
#                     # Improvement suggestions
#                     st.subheader("💡 Improvement Suggestions")
#                     if result['feedback']:
#                         st.markdown("""
#                         <div class='card'>
#                             <ul style='padding-left: 20px; margin-bottom: 0;'>
#                         """ + "\n".join([f"<li style='color: #2d3436;'>{suggestion}</li>" for suggestion in result['feedback']]) + """
#                             </ul>
#                         </div>
#                         """, unsafe_allow_html=True)
#                     else:
#                         st.success("No specific suggestions - your resume looks great!")
                    
#                     # Parsed text
#                     with st.expander("📝 View Parsed Text", expanded=False):
#                         st.text_area("Parsed Content", 
#                                    value=result['parsed_text'],
#                                    height=300,
#                                    label_visibility="collapsed")
                    
#                     # Download report
#                     report = generate_resume_report(result)
#                     st.download_button(
#                         label="📥 Download Full Analysis Report", 
#                         data=report,
#                         file_name="resume_analysis_report.txt",
#                         mime="text/plain",
#                         use_container_width=True,
#                         type="primary"
#                     )
                    
#                 except Exception as e:
#                     st.error(f"Unexpected error during analysis")
#                     with st.expander("View Error Details"):
#                         st.code(traceback.format_exc())

# def summary_section():
#     """Modern summary section with improved UI"""
#     with st.container():
#         # Header with icon
#         st.markdown("""
#         <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#             <div style='background: #00b09b; width: 48px; height: 48px; border-radius: 12px; 
#                         display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
#                 <span style='color: white; font-size: 24px;'>📋</span>
#             </div>
#             <div>
#                 <h2 style='margin: 0; color: #2d3436;'>Your Progress Summary</h2>
#                 <p style='margin: 0; color: #6c757d;'>Comprehensive evaluation across all modules</p>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Metrics cards
#         st.markdown("""
#         <div class='card'>
#             <h4 style='margin-top: 0; color: #2d3436;'>Your Scores</h4>
#             <div style='display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;'>
#         """, unsafe_allow_html=True)
        
#         # Interview Score
#         if 'interview' in st.session_state:
#             interview_score = sum(r['score'] for r in st.session_state.interview['responses'])
#             max_interview = len(st.session_state.interview['responses']) * 6
#             st.markdown(f"""
#             <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
#                 <h5 style='margin: 0 0 8px 0; color: #2d3436;'>Interview</h5>
#                 <h3 style='margin: 0; color: #2d3436;'>{interview_score}/{max_interview}</h3>
#                 <div style='margin-top: 8px;'>{st.progress(interview_score/max_interview)}</div>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown("""
#             <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
#                 <h5 style='margin: 0 0 8px 0; color: #2d3436;'>Interview</h5>
#                 <p style='margin: 0; color: #6c757d;'>Not completed</p>
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Self Assessment
#         if 'self_assessment_score' in st.session_state:
#             score = st.session_state.self_assessment_score
#             st.markdown(f"""
#             <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
#                 <h5 style='margin: 0 0 8px 0; color: #2d3436;'>Self Assessment</h5>
#                 <h3 style='margin: 0; color: #2d3436;'>{score}/100</h3>
#                 <div style='margin-top: 8px;'>{st.progress(score/100)}</div>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown("""
#             <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
#                 <h5 style='margin: 0 0 8px 0; color: #2d3436;'>Self Assessment</h5>
#                 <p style='margin: 0; color: #6c757d;'>Not completed</p>
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Resume Score
#         if 'resume_score' in st.session_state:
#             score = st.session_state.resume_score
#             st.markdown(f"""
#             <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
#                 <h5 style='margin: 0 0 8px 0; color: #2d3436;'>Resume</h5>
#                 <h3 style='margin: 0; color: #2d3436;'>{score}%</h3>
#                 <div style='margin-top: 8px;'>{st.progress(score/100)}</div>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown("""
#             <div style='background: white; border-radius: 12px; padding: 16px; border: 1px solid #e0e6ed; box-shadow: 0 4px 8px rgba(0,0,0,0.05);'>
#                 <h5 style='margin: 0 0 8px 0; color: #2d3436;'>Resume</h5>
#                 <p style='margin: 0; color: #6c757d;'>Not completed</p>
#             </div>
#             """, unsafe_allow_html=True)
        
#         st.markdown("</div></div>", unsafe_allow_html=True)
        
#         # Recommendations
#         st.subheader("📌 Recommended Next Steps")
        
#         recommendations = []
#         if 'resume_score' in st.session_state:
#             if st.session_state.resume_score < 70:
#                 recommendations.append("✏️ Improve your resume based on the feedback provided")
        
#         if 'self_assessment_score' in st.session_state:
#             if st.session_state.self_assessment_score < 70:
#                 recommendations.append("🧠 Focus on skill development in weaker areas")
        
#         if not recommendations:
#             recommendations.extend([
#                 "✅ You're doing great! Keep refining your materials",
#                 "🔍 Research target companies and roles",
#                 "🤝 Network with professionals in your field"
#             ])
        
#         st.markdown("""
#         <div class='card'>
#             <ul style='padding-left: 20px; margin-bottom: 0;'>
#         """ + "\n".join([f"<li style='color: #2d3436;'>{rec}</li>" for rec in recommendations]) + """
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
        
#         if st.button("🔄 Reset All Progress", use_container_width=True):
#             st.session_state.clear()
#             st.rerun()

# def main():
#     """Main application with enhanced UI"""
#     # Initialize session state for landing page
#     if 'show_landing' not in st.session_state:
#         st.session_state.show_landing = True
    
#     # Show landing page or main app
#     if st.session_state.show_landing:
#         landing_page()
#     else:
#         # Main app header with gradient
#         st.markdown("""
#         <div style='background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); 
#                     padding: 24px; 
#                     border-radius: 16px; 
#                     margin-bottom: 24px;
#                     color: white;'>
#             <h1 style='color: white; margin: 0;'>💼 Job Readiness Assistant</h1>
#             <p style='color: #000; margin: 0;'>Your comprehensive job preparation toolkit</p>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Sidebar navigation with enhanced UI
#         with st.sidebar:
#             st.markdown("""
#             <div style='padding: 16px; border-radius: 16px; background: linear-gradient(135deg, #2c3e50 0%, #4ca1af 100%); 
#                         margin-bottom: 24px; color: white;'>
#                 <h2 style='color: white; text-align: center; margin: 0;'>🔍 Navigation</h2>
#             </div>
#             """, unsafe_allow_html=True)
            
#             sections = {
#                 "📊 Self Assessment": self_assessment_section,
#                 "🤖 AI Interview Bot": run_interview,
#                 "📄 Resume Checker": resume_checker_section,
#                 "📋 Summary": summary_section
#             }
#             choice = st.radio(
#                 "Go to", 
#                 list(sections.keys()),
#                 label_visibility="collapsed"
#             )
            
#             st.markdown("---")
#             if st.button("🏠 Return to Home", use_container_width=True):
#                 st.session_state.show_landing = True
#                 st.rerun()
            
#             # Add a small footer
#             st.markdown("""
#             <div style='text-align: center; margin-top: 40px;'>
#                 <p style='font-size: 0.8em; color: #000; margin-bottom: 8px;'>
#                     Job Readiness Assistant v2.0
#                 </p>
#                 <p style='font-size: 0.7em; color: #000; margin: 0;'>
#                     © 2023 CareerPrep Tools
#                 </p>
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Display selected section
#         sections[choice]()

# if __name__ == "__main__":
#     main() 


# import streamlit as st
# from self_assessment.assessment import ask_questions, calculate_score, get_assessment_result
# from interview_bot.bot import run_interview
# from resume_checker.parser import parse_resume
# from resume_checker.ats_scoring import ats_score
# import traceback
# from datetime import datetime

# # Enhanced Custom CSS for better visibility and modern styling
# def inject_custom_css():
#     st.markdown("""
#     <style>
#         /* Main app styling */
#         .stApp {
#             background-color: #f8f9fa;
#             font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
#             line-height: 1.6;
#         }
        
#         /* Improved text contrast and readability */
#         body, .stTextInput input, .stTextArea textarea, .stSelectbox select {
#             color: #212529 !important;
#         }
        
#         /* Headers with better spacing and contrast */
#         h1, h2, h3, h4, h5, h6 {
#             color: #1a1a1a !important;
#             font-weight: 700;
#             margin-bottom: 0.75rem !important;
#         }
#         h1 { font-size: 2.5rem !important; }
#         h2 { font-size: 2rem !important; }
#         h3 { font-size: 1.75rem !important; }
#         h4 { font-size: 1.5rem !important; }
        
#         /* Paragraphs and text elements */
#         p, li, .stMarkdown {
#             color: #495057 !important;
#             font-size: 1rem !important;
#             line-height: 1.7 !important;
#         }
        
#         /* Buttons with better visual hierarchy */
#         .stButton>button {
#             border-radius: 12px !important;
#             padding: 12px 24px !important;
#             font-weight: 600 !important;
#             transition: all 0.3s ease !important;
#             background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%) !important;
#             color: white !important;
#             border: none !important;
#             font-size: 1rem !important;
#             box-shadow: 0 4px 6px rgba(0,0,0,0.1) !important;
#         }
#         .stButton>button:hover {
#             transform: translateY(-2px) !important;
#             box-shadow: 0 7px 14px rgba(0,0,0,0.15) !important;
#             opacity: 0.9 !important;
#         }
#         .stButton>button:focus {
#             outline: 2px solid rgba(106, 17, 203, 0.5) !important;
#         }
        
#         /* Cards with better shadows and spacing */
#         .card {
#             border-radius: 16px !important;
#             padding: 24px !important;
#             background: white !important;
#             box-shadow: 0 8px 20px rgba(0,0,0,0.08) !important;
#             margin-bottom: 24px !important;
#             border: none !important;
#         }
        
#         /* Progress bars with better visibility */
#         .stProgress > div > div > div {
#             background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%) !important;
#             border-radius: 8px !important;
#             height: 10px !important;
#         }
        
#         /* Metrics with improved contrast */
#         [data-testid="metric-container"] {
#             border: none !important;
#             border-radius: 12px !important;
#             padding: 20px !important;
#             background: white !important;
#             box-shadow: 0 4px 12px rgba(0,0,0,0.05) !important;
#         }
#         [data-testid="metric-label"] {
#             font-size: 1rem !important;
#             color: #495057 !important;
#             font-weight: 600 !important;
#         }
#         [data-testid="metric-value"] {
#             font-size: 1.75rem !important;
#             color: #1a1a1a !important;
#         }
        
#         /* Sidebar with better contrast */
#         [data-testid="stSidebar"] {
#             background: linear-gradient(180deg, #2c3e50 0%, #4ca1af 100%) !important;
#         }
#         .sidebar .sidebar-content {
#             color: white !important;
#         }
#         .sidebar .stRadio label {
#             color: white !important;
#             font-weight: 500 !important;
#             padding: 12px 16px !important;
#             border-radius: 12px !important;
#             margin: 8px 0 !important;
#             transition: all 0.3s ease !important;
#             background: rgba(255,255,255,0.05) !important;
#         }
#         .sidebar .stRadio label:hover {
#             background: rgba(255,255,255,0.1) !important;
#         }
#         .sidebar .stRadio [aria-checked="true"] label {
#             background: rgba(255,255,255,0.2) !important;
#             font-weight: 600 !important;
#         }
        
#         /* Success messages with better visibility */
#         .custom-success {
#             background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%) !important;
#             color: #155724 !important;
#             border-radius: 12px !important;
#             padding: 24px !important;
#             margin-bottom: 24px !important;
#             border-left: 5px solid #28a745 !important;
#         }
#         .custom-success h3 {
#             color: #155724 !important;
#         }
        
#         /* Error messages */
#         .stAlert {
#             border-radius: 12px !important;
#             padding: 16px !important;
#         }
        
#         /* Text inputs with better visibility */
#         .stTextArea textarea, .stTextInput input {
#             border-radius: 12px !important;
#             padding: 12px !important;
#             border: 1px solid #dee2e6 !important;
#             font-size: 1rem !important;
#         }
#         .stTextArea textarea:focus, .stTextInput input:focus {
#             border-color: #6a11cb !important;
#             box-shadow: 0 0 0 2px rgba(106, 17, 203, 0.2) !important;
#         }
        
#         /* Radio buttons with better contrast */
#         .stRadio [role="radiogroup"] {
#             gap: 12px !important;
#         }
#         .stRadio [role="radio"] {
#             padding: 12px 16px !important;
#             border-radius: 12px !important;
#             border: 1px solid #dee2e6 !important;
#             background: white !important;
#         }
#         .stRadio [role="radio"][aria-checked="true"] {
#             border: 2px solid #6a11cb !important;
#             background: rgba(106, 17, 203, 0.1) !important;
#         }
        
#         /* Expanders with better visibility */
#         .stExpander {
#             border-radius: 12px !important;
#             border: 1px solid #e0e6ed !important;
#             background: white !important;
#         }
#         .stExpander .st-expanderHeader {
#             font-weight: 600 !important;
#             color: #1a1a1a !important;
#         }
        
#         /* File uploader styling */
#         .stFileUploader {
#             border-radius: 12px !important;
#         }
#         .stFileUploader > label {
#             font-weight: 600 !important;
#             color: #1a1a1a !important;
#             margin-bottom: 8px !important;
#         }
        
#         /* Custom scrollbar for better UX */
#         ::-webkit-scrollbar {
#             width: 8px;
#             height: 8px;
#         }
#         ::-webkit-scrollbar-track {
#             background: #f1f1f1;
#             border-radius: 4px;
#         }
#         ::-webkit-scrollbar-thumb {
#             background: #6a11cb;
#             border-radius: 4px;
#         }
#         ::-webkit-scrollbar-thumb:hover {
#             background: #2575fc;
#         }
        
#         /* Better spacing overall */
#         .stContainer, .stColumn, .stHorizontalBlock {
#             gap: 16px !important;
#         }
        
#         /* Fix for dark text in cards */
#         .card h1, .card h2, .card h3, .card h4, .card h5, .card h6,
#         .card p, .card li {
#             color: #212529 !important;
#         }
        
#         /* List items with better spacing */
#         ul, ol {
#             padding-left: 24px !important;
#         }
#         li {
#             margin-bottom: 8px !important;
#         }
#     </style>
#     """, unsafe_allow_html=True)

# # Set page config with better metadata
# st.set_page_config(
#     page_title="Job Readiness Assistant Pro",
#     page_icon="💼",
#     layout="wide",
#     initial_sidebar_state="expanded",
#     menu_items={
#         'Get Help': 'https://example.com/help',
#         'Report a bug': "https://example.com/bug",
#         'About': "# Job Readiness Assistant\n### Your comprehensive career preparation tool"
#     }
# )

# # Inject custom CSS
# inject_custom_css()

# def generate_resume_report(result):
#     """Generate downloadable report with better formatting"""
#     report = f"""RESUME ANALYSIS REPORT
# =================================
# Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# Overall ATS Score: {result['percentage']}%

# SCORE BREAKDOWN:
# ----------------
# Keywords:       {result['breakdown'].get('keywords', 0)}/20
# Sections:       {result['breakdown'].get('sections', 0)}/20
# Experience:     {result['breakdown'].get('experience', 0)}/15
# Education:      {result['breakdown'].get('education', 0)}/10
# Achievements:   {result['breakdown'].get('achievements', 0)}/15
# Readability:    {result['breakdown'].get('readability', 0)}/10
# """
#     if result['breakdown'].get('custom', 0) > 0:
#         report += f"Job Match:      {result['breakdown'].get('custom', 0)}/10\n"

#     if 'feedback' in result and result['feedback']:
#         report += "\nIMPROVEMENT SUGGESTIONS:\n----------------\n"
#         report += "\n".join(f"- {suggestion}" for suggestion in result['feedback'])
    
#     if 'parsed_text' in result:
#         report += "\n\nPARSED TEXT EXCERPT:\n----------------\n"
#         excerpt = result['parsed_text'][:500]
#         report += excerpt + ("..." if len(result['parsed_text']) > 500 else "")
    
#     if result.get('warnings', []):
#         report += "\n\nPROCESSING NOTES:\n----------------\n"
#         report += "\n".join(f"- {warning}" for warning in result['warnings'])
    
#     return report

# def landing_page():
#     """Enhanced landing page with better visual hierarchy"""
#     # Hero section with improved contrast
#     st.markdown("""
#     <div style='background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); 
#                 padding: 60px 40px; 
#                 border-radius: 16px; 
#                 margin-bottom: 40px;
#                 color: white;
#                 text-align: center;'>
#         <h1 style='color: white; margin-bottom: 16px;'>🚀 Supercharge Your Job Search</h1>
#         <p style='font-size: 1.25rem; color: rgba(255,255,255,0.9); margin-bottom: 0;'>
#             Your all-in-one toolkit for resume optimization, skill assessment, and interview preparation
#         </p>
#     </div>
#     """, unsafe_allow_html=True)
    
#     # Value proposition cards with better spacing
#     st.subheader("✨ Why Choose Our Tool?", anchor=False)
#     cols = st.columns(3)
#     with cols[0]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 20px;'>
#                 <div style='background: #6a11cb; width: 56px; height: 56px; border-radius: 14px; 
#                             display: flex; align-items: center; justify-content: center; margin-right: 16px;'>
#                     <span style='color: white; font-size: 28px;'>📊</span>
#                 </div>
#                 <h3 style='margin: 0;'>Data-Driven Insights</h3>
#             </div>
#             <p>Get actionable recommendations based on real hiring data and ATS requirements to maximize your interview chances.</p>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with cols[1]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 20px;'>
#                 <div style='background: #2575fc; width: 56px; height: 56px; border-radius: 14px; 
#                             display: flex; align-items: center; justify-content: center; margin-right: 16px;'>
#                     <span style='color: white; font-size: 28px;'>💡</span>
#                 </div>
#                 <h3 style='margin: 0;'>Personalized Guidance</h3>
#             </div>
#             <p>Tailored feedback based on your unique profile, skills, and career goals for maximum relevance.</p>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with cols[2]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 20px;'>
#                 <div style='background: #00b09b; width: 56px; height: 56px; border-radius: 14px; 
#                             display: flex; align-items: center; justify-content: center; margin-right: 16px;'>
#                     <span style='color: white; font-size: 28px;'>⚡</span>
#                 </div>
#                 <h3 style='margin: 0;'>Proven Results</h3>
#             </div>
#             <p>Users report 3x more interview invitations after implementing our recommendations.</p>
#         </div>
#         """, unsafe_allow_html=True)
    
#     # CTA Button with better prominence
#     st.markdown("<br>", unsafe_allow_html=True)
#     col1, col2, col3 = st.columns([1,2,1])
#     with col2:
#         if st.button("🚀 Start Your Journey Now", use_container_width=True, type="primary", key="landing_cta"):
#             st.session_state.show_landing = False
#             st.rerun()
    
#     # Features section with improved organization
#     st.markdown("---")
#     st.subheader("🔍 Key Features", anchor=False)
    
#     features = st.columns(3)
#     with features[0]:
#         st.markdown("""
#         <div class='card'>
#             <h3 style='color: #6a11cb; margin-top: 0;'>Resume Analysis</h3>
#             <ul>
#                 <li>ATS compatibility scoring with detailed breakdown</li>
#                 <li>Keyword optimization for specific job titles</li>
#                 <li>Formatting and structure recommendations</li>
#                 <li>Job description matching analysis</li>
#                 <li>Downloadable improvement report</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with features[1]:
#         st.markdown("""
#         <div class='card'>
#             <h3 style='color: #2575fc; margin-top: 0;'>Skill Assessment</h3>
#             <ul>
#                 <li>Comprehensive evaluation across 10+ competencies</li>
#                 <li>Personalized development roadmap</li>
#                 <li>Benchmarking against industry standards</li>
#                 <li>Progress tracking over time</li>
#                 <li>Recommended learning resources</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with features[2]:
#         st.markdown("""
#         <div class='card'>
#             <h3 style='color: #00b09b; margin-top: 0;'>Mock Interviews</h3>
#             <ul>
#                 <li>Role-specific question bank</li>
#                 <li>AI-powered response analysis</li>
#                 <li>Performance scoring with detailed feedback</li>
#                 <li>Common mistakes identification</li>
#                 <li>Confidence-building exercises</li>
#             </ul>
#         </div>
#         """, unsafe_allow_html=True)
    
#     # Testimonials with better layout
#     st.markdown("---")
#     st.subheader("💬 Success Stories", anchor=False)
#     testimonials = st.columns(2)
#     with testimonials[0]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#                 <img src='https://randomuser.me/api/portraits/women/44.jpg' 
#                      style='width: 64px; height: 64px; border-radius: 50%; margin-right: 16px; object-fit: cover;'>
#                 <div>
#                     <h4 style='margin: 0;'>Sarah Johnson</h4>
#                     <p style='margin: 0; color: #6c757d;'>Marketing Director at TechCorp</p>
#                 </div>
#             </div>
#             <p style='font-style: italic; margin-bottom: 8px;'>
#                 "This tool helped me identify gaps in my resume I never noticed. After implementing the suggestions, 
#                 I landed 3 interviews in just 2 weeks! The ATS scoring was particularly eye-opening."
#             </p>
#             <div style='display: flex; align-items: center;'>
#                 <div style='color: gold; font-size: 20px; margin-right: 12px;'>★★★★★</div>
#                 <span style='color: #6c757d; font-size: 0.9rem;'>2 months ago</span>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)
    
#     with testimonials[1]:
#         st.markdown("""
#         <div class='card'>
#             <div style='display: flex; align-items: center; margin-bottom: 16px;'>
#                 <img src='https://randomuser.me/api/portraits/men/32.jpg' 
#                      style='width: 64px; height: 64px; border-radius: 50%; margin-right: 16px; object-fit: cover;'>
#                 <div>
#                     <h4 style='margin: 0;'>James Wilson</h4>
#                     <p style='margin: 0; color: #6c757d;'>Senior Software Engineer</p>
#                 </div>
#             </div>
#             <p style='font-style: italic; margin-bottom: 8px;'>
#                 "The mock interviews prepared me better than any book could. I walked into my real interview with 
#                 confidence and landed my dream job at a FAANG company. The feedback on my responses was invaluable."
#             </p>
#             <div style='display: flex; align-items: center;'>
#                 <div style='color: gold; font-size: 20px; margin-right: 12px;'>★★★★★</div>
#                 <span style='color: #6c757d; font-size: 0.9rem;'>3 weeks ago</span>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)

# def self_assessment_section():
#     """Enhanced self-assessment section with better UX"""
#     with st.container():
#         # Header with improved layout
#         st.markdown("""
#         <div style='display: flex; align-items: center; margin-bottom: 24px;'>
#             <div style='background: #6a11cb; width: 56px; height: 56px; border-radius: 14px; 
#                         display: flex; align-items: center; justify-content: center; margin-right: 16px;'>
#                 <span style='color: white; font-size: 28px;'>📊</span>
#             </div>
#             <div>
#                 <h2 style='margin: 0;'>Skill Assessment</h2>
#                 <p style='margin: 0; color: #6c757d;'>
#                     Evaluate your job readiness across key competencies to identify strengths and areas for improvement
#                 </p>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)
        
#         with st.expander("ℹ️ About this assessment", expanded=False):
#             st.write("""
#             This comprehensive assessment evaluates your skills across various dimensions important for career success. 
#             Answer each question honestly to receive the most accurate evaluation and personalized recommendations.
            
#             **Scoring:**
#             - 80-100: Excellent readiness
#             - 60-79: Good foundation with some areas to improve
#             - Below 60: Significant development opportunities
#             """)
        
#         questions = ask_questions()
#         responses = []
        
#         # Question cards with better spacing
#         for i, q in enumerate(questions):
#             with st.container():
#                 st.markdown(f"""
#                 <div class='card'>
#                     <div style='display: flex; align-items: flex-start;'>
#                         <div style='background: #f8f9fa; width: 36px; height: 36px; border-radius: 8px; 
#                                     display: flex; align-items: center; justify-content: center; margin-right: 12px;'>
#                             <span style='color: #6a11cb; font-weight: bold;'>{i+1}</span>
#                         </div>
#                         <h4 style='margin: 0;'>{q['question']}</h4>
#                     </div>
#                 </div>
#                 """, unsafe_allow_html=True)
                
#                 # Add a spacer
#                 st.markdown("<div style='height: 8px;'></div>", unsafe_allow_html=True)
                
#                 response = st.radio(
#                     "Select your answer:",
#                     q['options'],
#                     key=f"self_assess_q{i}",
#                     index=None,
#                     horizontal=True,
#                     label_visibility="collapsed"
#                 )
                
#                 if response is None and 'self_assessment_score' not in st.session_state:
#                     st.warning("Please select an answer to proceed")
#                     st.stop()
                
#                 if response is not None:
#                     responses.append(q['scores'][q['options'].index(response)])
        
#         if st.button("📊 Calculate My Score", use_container_width=True, type="primary"):
#             if len(responses) != len(questions):
#                 st.error("Please answer all questions before submitting")
#                 st.stop()
                
#             score = calculate_score(responses)
#             result = get_assessment_result(score)
#             st.session_state.self_assessment_score = score
            
#             # Results card with enhanced visualization
#             st.markdown(f"""
#             <div class='custom-success'>
#                 <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                     <h3 style='margin: 0;'>Assessment Complete!</h3>
#                     <div style='background: #28a745; color: white; padding: 8px 20px; border-radius: 20px; 
#                                 font-size: 1.25rem; font-weight: 600;'>
#                         {score}/100
#                     </div>
#                 </div>
#                 <p style='margin-bottom: 0; font-size: 1.1rem;'>{result}</p>
#             </div>
#             """, unsafe_allow_html=True)
            
#             # Feedback section with actionable items
#             st.subheader("📝 Personalized Feedback", anchor=False)
            
#             if score < 50:
#                 st.markdown("""
#                 <div class='card' style='border-left: 5px solid #dc3545;'>
#                     <h4 style='color: #dc3545; margin-top: 0;'>Areas for Improvement</h4>
#                     <p>Based on your assessment, we recommend focusing on these areas:</p>
#                     <ul>
#                         <li><strong>Skill development:</strong> Identify 2-3 key skills to develop based on your career goals</li>
#                         <li><strong>Learning plan:</strong> Create a structured 90-day learning plan with measurable milestones</li>
#                         <li><strong>Practical application:</strong> Seek projects or volunteer opportunities to practice these skills</li>
#                         <li><strong>Mentorship:</strong> Connect with experienced professionals in your field for guidance</li>
#                     </ul>
#                     <p><strong>Recommended resources:</strong> LinkedIn Learning paths, Coursera specializations, and local workshops</p>
#                 </div>
#                 """, unsafe_allow_html=True)
#             elif score < 80:
#                 st.markdown("""
#                 <div class='card' style='border-left: 5px solid #ffc107;'>
#                     <h4 style='color: #ffc107; margin-top: 0;'>Good Progress</h4>
#                     <p>You have a solid foundation with some areas to strengthen:</p>
#                     <ul>
#                         <li><strong>Interview preparation:</strong> Practice behavioral and technical interview questions</li>
#                         <li><strong>Career clarity:</strong> Refine your career goals and target positions</li>
#                         <li><strong>Networking:</strong> Expand your professional network by 10-15 relevant connections</li>
#                         <li><strong>Personal branding:</strong> Update your LinkedIn profile and online presence</li>
#                     </ul>
#                     <p><strong>Recommended resources:</strong> Mock interview platforms, career coaching, networking events</p>
#                 </div>
#                 """, unsafe_allow_html=True)
#             else:
#                 st.markdown("""
#                 <div class='card' style='border-left: 5px solid #28a745;'>
#                     <h4 style='color: #28a745; margin-top: 0;'>Excellent Readiness</h4>
#                     <p>You're well-prepared for your job search! Consider these next steps:</p>
#                     <ul>
#                         <li><strong>Leadership opportunities:</strong> Seek roles with greater responsibility</li>
#                         <li><strong>Mentorship:</strong> Share your knowledge by mentoring others</li>
#                         <li><strong>Continuous learning:</strong> Stay current with emerging trends in your field</li>
#                         <li><strong>Strategic networking:</strong> Build relationships with decision-makers</li>
#                     </ul>
#                     <p><strong>Recommended resources:</strong> Executive education programs, industry conferences</p>
#                 </div>
#                 """, unsafe_allow_html=True)

# def resume_checker_section():
#     """Enhanced resume checker with better file handling and feedback"""
#     with st.container():
#         # Header with improved layout
#         st.markdown("""
#         <div style='display: flex; align-items: center; margin-bottom: 24px;'>
#             <div style='background: #2575fc; width: 56px; height: 56px; border-radius: 14px; 
#                         display: flex; align-items: center; justify-content: center; margin-right: 16px;'>
#                 <span style='color: white; font-size: 28px;'>📄</span>
#             </div>
#             <div>
#                 <h2 style='margin: 0;'>Resume Analysis</h2>
#                 <p style='margin: 0; color: #6c757d;'>
#                     Optimize your resume for Applicant Tracking Systems and human recruiters
#                 </p>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Optional job description input with better instructions
#         with st.expander("🔍 Add Job Description for Targeted Analysis (Recommended)", expanded=False):
#             job_description = st.text_area(
#                 "Paste the job description you're applying for:",
#                 height=200,
#                 help="Adding a job description enables us to analyze how well your resume matches the specific requirements of the role.",
#                 placeholder="Paste the job description here...\n\nExample:\n'Seeking a Marketing Manager with 5+ years experience in digital marketing, SEO/SEM, and team leadership. Bachelor's degree required. Experience with marketing automation tools preferred.'",
#                 key="job_desc_textarea"
#             )
        
#         # File uploader with better instructions
#         uploaded_file = st.file_uploader(
#             "Upload your resume (PDF or DOCX):", 
#             type=["pdf", "docx"],
#             help="For best results, upload a resume in PDF format. DOCX is also supported but may have slightly reduced accuracy.",
#             label_visibility="visible",
#             key="resume_uploader"
#         )
        
#         if uploaded_file:
#             with st.spinner("🔍 Analyzing your resume... This may take a moment."):
#                 try:
#                     text = parse_resume(uploaded_file)
                    
#                     # Pass job description if provided
#                     job_desc = job_description if job_description and job_description.strip() else None
#                     result = ats_score(text, job_desc)
                    
#                     if 'error' in result:
#                         st.error(f"Analysis failed: {result['error']}")
#                         with st.expander("Technical Details"):
#                             st.code(result.get('parsed_text', 'No additional details available'))
#                         return
                    
#                     # Store results in session state
#                     st.session_state.resume_data = result
#                     st.session_state.resume_score = result['percentage']
                    
#                     # Results header with better visual hierarchy
#                     st.markdown(f"""
#                     <div class='custom-success'>
#                         <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                             <h3 style='margin: 0;'>Analysis Complete!</h3>
#                             <div style='background: #28a745; color: white; padding: 8px 20px; border-radius: 20px; 
#                                         font-size: 1.25rem; font-weight: 600;'>
#                                 {result['percentage']}%
#                             </div>
#                         </div>
#                         <p style='margin-bottom: 0; font-size: 1.1rem;'>
#                             Your resume's ATS compatibility score - {get_ats_score_interpretation(result['percentage'])}
#                         </p>
#                     </div>
#                     """, unsafe_allow_html=True)
                    
#                     # Score visualization with better metrics
#                     col1, col2 = st.columns([1, 3])
#                     with col1:
#                         st.metric(
#                             "ATS Score", 
#                             f"{result['percentage']}%",
#                             help="How well your resume will parse in Applicant Tracking Systems"
#                         )
#                         st.metric(
#                             "Estimated Improvement", 
#                             f"+{min(40, 100 - result['percentage'])}% potential",
#                             help="Potential score increase after implementing suggestions",
#                             delta_color="off"
#                         )
#                     with col2:
#                         st.progress(result['percentage']/100)
#                         st.caption(f"Score interpretation: {get_ats_score_interpretation(result['percentage'])}")
                    
#                     # Show warnings if any
#                     if result.get('warnings', []):
#                         with st.expander("⚠️ Important Notes About Your Resume", expanded=True):
#                             for warning in result['warnings']:
#                                 st.warning(warning)
                    
#                     # Detailed breakdown with better organization
#                     with st.expander("📊 Detailed Score Breakdown", expanded=True):
#                         breakdown = result['breakdown']
                        
#                         st.write("#### Key Components:")
                        
#                         # First row - 4 metrics
#                         col1, col2, col3, col4 = st.columns(4)
                        
#                         with col1:
#                             st.metric(
#                                 "Keywords", 
#                                 f"{breakdown.get('keywords', 0)}/20",
#                                 help="Relevant industry keywords and skills found in your resume",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('keywords', 0)/20))
                            
#                         with col2:
#                             st.metric(
#                                 "Sections", 
#                                 f"{breakdown.get('sections', 0)}/20",
#                                 help="Proper resume sections (Experience, Education, Skills, etc.)",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('sections', 0)/20))
                            
#                         with col3:
#                             st.metric(
#                                 "Experience", 
#                                 f"{breakdown.get('experience', 0)}/15",
#                                 help="Quality, relevance, and impact of your work experience",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('experience', 0)/15))
                            
#                         with col4:
#                             st.metric(
#                                 "Education", 
#                                 f"{breakdown.get('education', 0)}/10",
#                                 help="Education background and relevance to the position",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('education', 0)/10))
                        
#                         # Second row - 3 metrics
#                         col1, col2, col3 = st.columns(3)
                        
#                         with col1:
#                             st.metric(
#                                 "Achievements", 
#                                 f"{breakdown.get('achievements', 0)}/15",
#                                 help="Measurable accomplishments and quantifiable impact",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('achievements', 0)/15))
                            
#                         with col2:
#                             st.metric(
#                                 "Readability", 
#                                 f"{breakdown.get('readability', 0)}/10",
#                                 help="Clarity, organization, and scannability of your content",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, breakdown.get('readability', 0)/10))
                            
#                         with col3:
#                             custom_score = breakdown.get('custom', 0)
#                             label = "Job Match" if job_desc else "Custom"
#                             st.metric(
#                                 label, 
#                                 f"{custom_score}/10",
#                                 help="Match with specific job description requirements" if job_desc else "Custom scoring component",
#                                 delta_color="off"
#                             )
#                             st.progress(min(1.0, custom_score/10))
                    
#                     # Improvement suggestions with priority indicators
#                     st.subheader("💡 Actionable Improvement Suggestions", anchor=False)
#                     if result['feedback']:
#                         st.markdown("""
#                         <div class='card'>
#                             <h4 style='margin-top: 0;'>Priority Recommendations</h4>
#                             <ol style='padding-left: 20px; margin-bottom: 0;'>
#                         """ + "\n".join([
#                             f"<li style='color: #2d3436; margin-bottom: 12px;'><strong>{suggestion}</strong><br>"
#                             f"<span style='color: #6c757d; font-size: 0.9rem;'>Expected impact: +{min(15, (100 - result['percentage'])//len(result['feedback']))}% score improvement</span></li>" 
#                             for suggestion in result['feedback']
#                         ]) + """
#                             </ol>
#                         </div>
#                         """, unsafe_allow_html=True)
#                     else:
#                         st.success("No specific suggestions - your resume looks great for ATS parsing!")
                    
#                     # Parsed text with better formatting
#                     with st.expander("📝 View Parsed Resume Content", expanded=False):
#                         st.text_area(
#                             "Parsed Content (for your reference)", 
#                             value=result['parsed_text'],
#                             height=300,
#                             label_visibility="collapsed",
#                             help="This shows how the ATS interprets your resume content"
#                         )
                    
#                     # Download report with better formatting
#                     report = generate_resume_report(result)
#                     st.download_button(
#                         label="📥 Download Full Analysis Report (PDF)", 
#                         data=report,
#                         file_name=f"resume_analysis_report_{datetime.now().strftime('%Y%m%d')}.txt",
#                         mime="text/plain",
#                         use_container_width=True,
#                         type="primary",
#                         help="Download a detailed report with all findings and recommendations"
#                     )
                    
#                 except Exception as e:
#                     st.error("An unexpected error occurred during analysis. Please try again.")
#                     with st.expander("Technical Details (For Support)"):
#                         st.code(traceback.format_exc())

# def get_ats_score_interpretation(score):
#     """Helper function to interpret ATS score"""
#     if score >= 90:
#         return "Excellent - Very likely to pass ATS screening"
#     elif score >= 75:
#         return "Good - Likely to pass most ATS systems"
#     elif score >= 60:
#         return "Fair - Might pass some ATS systems but needs improvement"
#     elif score >= 40:
#         return "Poor - Unlikely to pass ATS screening without changes"
#     else:
#         return "Very Poor - Significant improvements needed for ATS compatibility"

# def summary_section():
#     """Enhanced summary section with better data visualization"""
#     with st.container():
#         # Header with improved layout
#         st.markdown("""
#         <div style='display: flex; align-items: center; margin-bottom: 24px;'>
#             <div style='background: #00b09b; width: 56px; height: 56px; border-radius: 14px; 
#                         display: flex; align-items: center; justify-content: center; margin-right: 16px;'>
#                 <span style='color: white; font-size: 28px;'>📋</span>
#             </div>
#             <div>
#                 <h2 style='margin: 0;'>Your Career Readiness Dashboard</h2>
#                 <p style='margin: 0; color: #6c757d;'>
#                     Comprehensive evaluation of your job search preparation across all modules
#                 </p>
#             </div>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Metrics cards with better visualization
#         st.markdown("""
#         <div class='card'>
#             <h4 style='margin-top: 0;'>Your Progress Overview</h4>
#             <div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;'>
#         """, unsafe_allow_html=True)
        
#         # Interview Score
#         if 'interview' in st.session_state:
#             interview_score = sum(r['score'] for r in st.session_state.interview['responses'])
#             max_interview = len(st.session_state.interview['responses']) * 6
#             percentage = (interview_score/max_interview)*100
#             st.markdown(f"""
#             <div style='background: white; border-radius: 12px; padding: 20px; border-left: 5px solid #6a11cb;'>
#                 <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                     <h5 style='margin: 0; color: #6a11cb;'>Interview Performance</h5>
#                     <div style='background: #f8f9fa; color: #6a11cb; padding: 6px 12px; border-radius: 16px; 
#                                 font-weight: 600; font-size: 0.9rem;'>
#                         {interview_score}/{max_interview}
#                     </div>
#                 </div>
#                 <p style='margin: 0 0 12px 0; color: #6c757d; font-size: 0.9rem;'>
#                     {get_interview_interpretation(percentage)}
#                 </p>
#                 <div style='height: 8px; background: #f1f1f1; border-radius: 4px; margin-bottom: 8px;'>
#                     <div style='width: {percentage}%; height: 100%; background: linear-gradient(90deg, #6a11cb 0%, #2575fc 100%); 
#                                 border-radius: 4px;'></div>
#                 </div>
#                 <p style='margin: 0; text-align: right; color: #6c757d; font-size: 0.8rem;'>
#                     {percentage:.0f}% complete
#                 </p>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown("""
#             <div style='background: white; border-radius: 12px; padding: 20px; border-left: 5px solid #adb5bd;'>
#                 <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                     <h5 style='margin: 0; color: #6c757d;'>Interview Performance</h5>
#                     <div style='background: #f8f9fa; color: #6c757d; padding: 6px 12px; border-radius: 16px; 
#                                 font-weight: 600; font-size: 0.9rem;'>
#                         Not completed
#                     </div>
#                 </div>
#                 <p style='margin: 0 0 12px 0; color: #6c757d; font-size: 0.9rem;'>
#                     Complete a mock interview to assess your performance
#                 </p>
#                 <div style='height: 8px; background: #f1f1f1; border-radius: 4px; margin-bottom: 8px;'>
#                     <div style='width: 0%; height: 100%; background: #adb5bd; border-radius: 4px;'></div>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Self Assessment
#         if 'self_assessment_score' in st.session_state:
#             score = st.session_state.self_assessment_score
#             st.markdown(f"""
#             <div style='background: white; border-radius: 12px; padding: 20px; border-left: 5px solid #2575fc;'>
#                 <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                     <h5 style='margin: 0; color: #2575fc;'>Skill Assessment</h5>
#                     <div style='background: #f8f9fa; color: #2575fc; padding: 6px 12px; border-radius: 16px; 
#                                 font-weight: 600; font-size: 0.9rem;'>
#                         {score}/100
#                     </div>
#                 </div>
#                 <p style='margin: 0 0 12px 0; color: #6c757d; font-size: 0.9rem;'>
#                     {get_assessment_result(score)}
#                 </p>
#                 <div style='height: 8px; background: #f1f1f1; border-radius: 4px; margin-bottom: 8px;'>
#                     <div style='width: {score}%; height: 100%; background: linear-gradient(90deg, #2575fc 0%, #00b09b 100%); 
#                                 border-radius: 4px;'></div>
#                 </div>
#                 <p style='margin: 0; text-align: right; color: #6c757d; font-size: 0.8rem;'>
#                     {score}% complete
#                 </p>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown("""
#             <div style='background: white; border-radius: 12px; padding: 20px; border-left: 5px solid #adb5bd;'>
#                 <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                     <h5 style='margin: 0; color: #6c757d;'>Skill Assessment</h5>
#                     <div style='background: #f8f9fa; color: #6c757d; padding: 6px 12px; border-radius: 16px; 
#                                 font-weight: 600; font-size: 0.9rem;'>
#                         Not completed
#                     </div>
#                 </div>
#                 <p style='margin: 0 0 12px 0; color: #6c757d; font-size: 0.9rem;'>
#                     Complete the skill assessment to evaluate your readiness
#                 </p>
#                 <div style='height: 8px; background: #f1f1f1; border-radius: 4px; margin-bottom: 8px;'>
#                     <div style='width: 0%; height: 100%; background: #adb5bd; border-radius: 4px;'></div>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Resume Score
#         if 'resume_score' in st.session_state:
#             score = st.session_state.resume_score
#             st.markdown(f"""
#             <div style='background: white; border-radius: 12px; padding: 20px; border-left: 5px solid #00b09b;'>
#                 <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                     <h5 style='margin: 0; color: #00b09b;'>Resume Quality</h5>
#                     <div style='background: #f8f9fa; color: #00b09b; padding: 6px 12px; border-radius: 16px; 
#                                 font-weight: 600; font-size: 0.9rem;'>
#                         {score}%
#                     </div>
#                 </div>
#                 <p style='margin: 0 0 12px 0; color: #6c757d; font-size: 0.9rem;'>
#                     {get_ats_score_interpretation(score)}
#                 </p>
#                 <div style='height: 8px; background: #f1f1f1; border-radius: 4px; margin-bottom: 8px;'>
#                     <div style='width: {score}%; height: 100%; background: linear-gradient(90deg, #00b09b 0%, #96c93d 100%); 
#                                 border-radius: 4px;'></div>
#                 </div>
#                 <p style='margin: 0; text-align: right; color: #6c757d; font-size: 0.8rem;'>
#                     {score}% complete
#                 </p>
#             </div>
#             """, unsafe_allow_html=True)
#         else:
#             st.markdown("""
#             <div style='background: white; border-radius: 12px; padding: 20px; border-left: 5px solid #adb5bd;'>
#                 <div style='display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;'>
#                     <h5 style='margin: 0; color: #6c757d;'>Resume Quality</h5>
#                     <div style='background: #f8f9fa; color: #6c757d; padding: 6px 12px; border-radius: 16px; 
#                                 font-weight: 600; font-size: 0.9rem;'>
#                         Not analyzed
#                     </div>
#                 </div>
#                 <p style='margin: 0 0 12px 0; color: #6c757d; font-size: 0.9rem;'>
#                     Upload your resume for ATS compatibility analysis
#                 </p>
#                 <div style='height: 8px; background: #f1f1f1; border-radius: 4px; margin-bottom: 8px;'>
#                     <div style='width: 0%; height: 100%; background: #adb5bd; border-radius: 4px;'></div>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
        
#         st.markdown("</div></div>", unsafe_allow_html=True)
        
#         # Recommendations with priority levels
#         st.subheader("📌 Your Personalized Action Plan", anchor=False)
        
#         recommendations = []
#         priority = []
        
#         if 'resume_score' in st.session_state:
#             if st.session_state.resume_score < 70:
#                 priority.append("✏️ Improve your resume based on the detailed feedback provided to increase ATS compatibility")
#             else:
#                 recommendations.append("✅ Your resume is in good shape! Consider fine-tuning for specific roles")
        
#         if 'self_assessment_score' in st.session_state:
#             if st.session_state.self_assessment_score < 70:
#                 priority.append("🧠 Focus on skill development in weaker areas identified in your assessment")
#             else:
#                 recommendations.append("✅ Your skills are well-developed! Consider advanced certifications")
        
#         if 'interview' not in st.session_state:
#             priority.append("🎤 Complete a mock interview to practice your responses and identify improvement areas")
        
#         if not priority and not recommendations:
#             recommendations.extend([
#                 "🔍 Research target companies and roles to tailor your applications",
#                 "🤝 Expand your professional network by connecting with 10+ industry professionals this week",
#                 "📅 Schedule time each week for career development activities"
#             ])
        
#         if priority:
#             st.markdown("""
#             <div class='card' style='border-left: 5px solid #dc3545;'>
#                 <h4 style='margin-top: 0; color: #dc3545;'>High Priority Actions</h4>
#                 <ul style='padding-left: 20px; margin-bottom: 0;'>
#             """ + "\n".join([f"<li style='color: #2d3436;'>{item}</li>" for item in priority]) + """
#                 </ul>
#             </div>
#             """, unsafe_allow_html=True)
        
#         if recommendations:
#             st.markdown("""
#             <div class='card' style='border-left: 5px solid #28a745;'>
#                 <h4 style='margin-top: 0; color: #28a745;'>Recommended Next Steps</h4>
#                 <ul style='padding-left: 20px; margin-bottom: 0;'>
#             """ + "\n".join([f"<li style='color: #2d3436;'>{item}</li>" for item in recommendations]) + """
#                 </ul>
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Reset button with confirmation
#         if st.button("🔄 Reset All Progress", use_container_width=True, key="reset_button"):
#             st.warning("Are you sure you want to reset all your progress? This cannot be undone.")
#             col1, col2, col3 = st.columns([1,1,1])
#             with col2:
#                 if st.button("✅ Confirm Reset", type="primary", use_container_width=True):
#                     st.session_state.clear()
#                     st.rerun()

# def get_interview_interpretation(percentage):
#     """Helper function to interpret interview score"""
#     if percentage >= 85:
#         return "Excellent performance - You're well prepared for real interviews"
#     elif percentage >= 70:
#         return "Good performance - Some areas to polish before real interviews"
#     elif percentage >= 50:
#         return "Fair performance - Needs significant improvement in several areas"
#     else:
#         return "Needs work - Focus on preparation before interviewing"

# def main():
#     """Main application with enhanced navigation and state management"""
#     # Initialize session state for landing page
#     if 'show_landing' not in st.session_state:
#         st.session_state.show_landing = True
    
#     # Show landing page or main app
#     if st.session_state.show_landing:
#         landing_page()
#     else:
#         # Main app header with better visual hierarchy
#         st.markdown("""
#         <div style='background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%); 
#                     padding: 32px 40px; 
#                     border-radius: 16px; 
#                     margin-bottom: 32px;
#                     color: white;
#                     box-shadow: 0 8px 20px rgba(0,0,0,0.15);'>
#             <h1 style='color: white; margin-bottom: 8px;'>💼 Job Readiness Assistant Pro</h1>
#             <p style='font-size: 1.1rem; color: rgba(255,255,255,0.9); margin-bottom: 0;'>
#                 Your comprehensive career preparation toolkit
#             </p>
#         </div>
#         """, unsafe_allow_html=True)
        
#         # Enhanced sidebar navigation
#         with st.sidebar:
#             st.markdown("""
#             <div style='padding: 20px; border-radius: 16px; 
#                         background: linear-gradient(135deg, #2c3e50 0%, #4ca1af 100%);
#                         margin-bottom: 24px; 
#                         box-shadow: 0 4px 12px rgba(0,0,0,0.1);'>
#                 <h2 style='color: white; text-align: center; margin: 0 0 16px 0;'>🔍 Navigation</h2>
#                 <p style='color: rgba(255,255,255,0.9); text-align: center; margin: 0; font-size: 0.9rem;'>
#                     Select a module to continue your preparation
#                 </p>
#             </div>
#             """, unsafe_allow_html=True)
            
#             sections = {
#                 "📊 Self Assessment": self_assessment_section,
#                 "🤖 AI Interview Bot": run_interview,
#                 "📄 Resume Checker": resume_checker_section,
#                 "📋 Summary Dashboard": summary_section
#             }
            
#             # Add icons to the radio buttons
#             choice = st.radio(
#                 "Go to", 
#                 list(sections.keys()),
#                 label_visibility="collapsed",
#                 key="nav_choice"
#             )
            
#             st.markdown("---")
            
#             # Home button with better styling
#             if st.button("🏠 Return to Home", 
#                         use_container_width=True, 
#                         key="home_button",
#                         help="Go back to the landing page"):
#                 st.session_state.show_landing = True
#                 st.rerun()
            
#             # Add a user profile section
#             st.markdown("---")
#             st.markdown("""
#             <div style='display: flex; align-items: center; padding: 12px; border-radius: 12px; 
#                         background: rgba(255,255,255,0.1); margin-top: 20px;'>
#                 <div style='width: 40px; height: 40px; border-radius: 50%; 
#                             background: #6a11cb; display: flex; align-items: center; 
#                             justify-content: center; margin-right: 12px;'>
#                     <span style='color: white; font-size: 18px;'>👤</span>
#                 </div>
#                 <div>
#                     <p style='margin: 0; font-weight: 600; color: white;'>User Profile</p>
#                     <p style='margin: 0; font-size: 0.8rem; color: rgba(255,255,255,0.8);'>
#                         {progress_summary()}
#                     </p>
#                 </div>
#             </div>
#             """, unsafe_allow_html=True)
            
#             # Add a small footer with better visibility
#             st.markdown("""
#             <div style='text-align: center; margin-top: 40px;'>
#                 <p style='font-size: 0.8rem; color: rgba(255,255,255,0.7); margin-bottom: 8px;'>
#                     Job Readiness Assistant Pro v2.1
#                 </p>
#                 <p style='font-size: 0.7rem; color: rgba(255,255,255,0.5); margin: 0;'>
#                     © 2023 CareerPrep Tools | All Rights Reserved
#                 </p>
#             </div>
#             """, unsafe_allow_html=True)
        
#         # Display selected section
#         sections[choice]()

# def progress_summary():
#     """Generate a summary of completed sections"""
#     completed = 0
#     total = 3  # Resume, Assessment, Interview
    
#     if 'resume_score' in st.session_state:
#         completed += 1
#     if 'self_assessment_score' in st.session_state:
#         completed += 1
#     if 'interview' in st.session_state:
#         completed += 1
    
#     return f"{completed} of {total} modules completed"

# if __name__ == "__main__":
#     main()