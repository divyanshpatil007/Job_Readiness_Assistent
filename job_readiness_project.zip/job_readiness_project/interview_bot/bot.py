import json
import random
from textblob import TextBlob
import streamlit as st
import pyttsx3
import speech_recognition as sr
from queue import Queue
import threading
import time

# Initialize speech engine
try:
    engine = pyttsx3.init()
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[0].id)  # Use first available voice
    engine.setProperty('rate', 150)  # Slower speech rate
except Exception as e:
    st.warning(f"Text-to-speech initialization failed: {e}")
    engine = None

# Create a queue for speech recognition
speech_queue = Queue()

def speak(text):
    """Convert text to speech"""
    if engine is None:
        st.warning("Text-to-speech not available. Please enable it in your system.")
        return
        
    def _speak():
        try:
            engine.say(text)
            engine.runAndWait()
        except Exception as e:
            st.error(f"Error in speech synthesis: {e}")
    
    # Run in a separate thread to avoid blocking
    threading.Thread(target=_speak, daemon=True).start()

def listen_in_background():
    """Continuous listening in background"""
    r = sr.Recognizer()
    r.pause_threshold = 0.8  # Silence duration to end speech
    r.energy_threshold = 4000  # Adjust for microphone sensitivity
    
    with sr.Microphone() as source:
        st.session_state.listening = True
        st.rerun()  # Update UI to show listening state
        
        while st.session_state.get('listening', False):
            try:
                audio = r.listen(source, timeout=3, phrase_time_limit=10)
                text = r.recognize_google(audio)
                speech_queue.put(text)
            except sr.WaitTimeoutError:
                continue
            except sr.UnknownValueError:
                speech_queue.put(None)  # Signal recognition failure
            except Exception as e:
                st.error(f"Listening error: {e}")
                speech_queue.put(None)
                break

def start_listening():
    """Start the listening thread"""
    if 'listening_thread' not in st.session_state or not st.session_state.listening_thread.is_alive():
        st.session_state.listening = True
        st.session_state.listening_thread = threading.Thread(
            target=listen_in_background, 
            daemon=True
        )
        st.session_state.listening_thread.start()

def stop_listening():
    """Stop the listening thread"""
    st.session_state.listening = False
    if 'listening_thread' in st.session_state:
        st.session_state.listening_thread.join(timeout=1)

def load_questions(path="data/interview_questions/questions.json"):
    """Load interview questions from JSON file"""
    try:
        with open(path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        st.error("Questions file not found! Using default questions.")
        return [
            "Tell me about yourself.",
            "What are your strengths and weaknesses?",
            "Why do you want to work here?",
            "Where do you see yourself in 5 years?",
            "Describe a challenging work situation and how you overcame it."
        ]

def analyze_sentiment(response):
    """Analyze the sentiment of a response"""
    blob = TextBlob(response)
    sentiment = blob.sentiment.polarity
    if sentiment > 0.1:
        return "Positive"
    elif sentiment < -0.1:
        return "Negative"
    return "Neutral"

def evaluate_response(response):
    """Evaluate the quality of a response"""
    sentiment = analyze_sentiment(response)
    length = len(response.strip().split())

    score = 0
    # Sentiment scoring
    score += {"Positive": 3, "Neutral": 2, "Negative": 1}[sentiment]
    
    # Length scoring
    if length < 10:
        score += 1  # Short answer
    elif length < 30:
        score += 2  # Moderate answer
    else:
        score += 3  # Detailed answer
    
    return score, sentiment

def get_follow_up(question, response):
    """Generate relevant follow-up questions"""
    follow_ups = {
        "Tell me about yourself.": [
            "What interests you most about this position?",
            "How does your background make you a good fit?"
        ],
        "What are your strengths and weaknesses?": [
            "Can you give an example of using your strength in a work setting?",
            "How are you working to improve your weaknesses?"
        ],
        "Why do you want to work here?": [
            "What do you know about our company culture?",
            "How does this role align with your career goals?"
        ],
        "Describe a challenging work situation and how you overcame it.": [
            "What did you learn from that experience?",
            "How would you handle a similar situation differently now?"
        ]
    }
    return random.choice(follow_ups.get(question, [
        "Can you elaborate on that?",
        "What makes you say that?",
        "Could you give me an example?"
    ]))

def initialize_interview():
    """Initialize interview session state"""
    if 'interview' not in st.session_state:
        st.session_state.interview = {
            'questions': load_questions(),
            'current_q': 0,
            'responses': [],
            'follow_up': None,
            'completed': False,
            'feedback_shown': False,
            'speech_enabled': False,
            'listening': False
        }

def display_question():
    """Display current question or follow-up"""
    interview = st.session_state.interview
    if interview['follow_up']:
        return interview['follow_up']
    return interview['questions'][interview['current_q']]

def process_answer(answer):
    """Process user's answer and update state"""
    interview = st.session_state.interview
    
    # Evaluate response
    score, sentiment = evaluate_response(answer)
    question_text = display_question()
    
    # Store response
    interview['responses'].append({
        'question': question_text,
        'response': answer,
        'score': score,
        'sentiment': sentiment
    })
    
    # Determine next step
    if interview['follow_up']:
        interview['current_q'] += 1
        interview['follow_up'] = None
        if interview['current_q'] >= len(interview['questions']):
            interview['completed'] = True
    else:
        interview['follow_up'] = get_follow_up(
            interview['questions'][interview['current_q']],
            answer
        )
    
    st.rerun()

def show_feedback():
    """Display interview feedback summary"""
    interview = st.session_state.interview
    total_score = sum(r['score'] for r in interview['responses'])
    max_score = len(interview['responses']) * 6  # Max 6 points per question
    
    st.subheader("🎯 Interview Results")
    st.progress(total_score / max_score)
    st.write(f"**Total Score:** {total_score}/{max_score} ({round(total_score/max_score*100)}%)")
    
    st.subheader("📝 Detailed Feedback")
    for i, resp in enumerate(interview['responses']):
        with st.expander(f"❓ Question {i+1}: {resp['question']}"):
            st.write(f"**🗣 Your Answer:** {resp['response']}")
            st.write(f"**⭐ Score:** {resp['score']}/6")
            st.write(f"**😊 Sentiment:** {resp['sentiment']}")
            st.write(f"**📏 Length:** {len(resp['response'].split())} words")
    
    if st.button("🔄 Start New Interview"):
        del st.session_state.interview
        st.rerun()

def run_interview():
    """Main interview interface with voice control"""
    # Initialize session state
    initialize_interview()
    interview = st.session_state.interview
    
    # Check for speech recognition results
    if not speech_queue.empty():
        answer = speech_queue.get()
        if answer:
            process_answer(answer)
        else:
            st.warning("Sorry, I didn't catch that. Please try again.")
    
    # UI Controls
    st.subheader("🤖 AI Interview Bot")
    interview['speech_enabled'] = st.checkbox(
        "🎙️ Enable Voice Interaction", 
        value=interview['speech_enabled'],
        help="Allow the bot to speak questions and listen to your answers"
    )
    
    # Main interview flow
    if interview['completed']:
        show_feedback()
        return
    
    # Display current question
    question = display_question()
    st.markdown(f"### ❓ {question}")
    
    # Speak the question if enabled
    if interview['speech_enabled'] and engine:
        speak(question)
    
    # Answer input section
    if interview['speech_enabled']:
        st.write("### 🎤 Answer Options:")
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🎤 Speak Answer", help="Press and speak your answer"):
                start_listening()
                
        with col2:
            if st.button("✋ Stop Listening", disabled=not st.session_state.get('listening', False)):
                stop_listening()
        
        # Visual feedback for listening state
        if st.session_state.get('listening', False):
            st.warning("👂 Listening... Speak now!")
        
        # Text fallback
        answer = st.text_area("Or type your answer:", key=f"answer_{interview['current_q']}")
    else:
        answer = st.text_area("✏️ Your Answer:", key=f"answer_{interview['current_q']}")
    
    # Submit button
    if st.button("📤 Submit Answer"):
        if answer and answer.strip():
            process_answer(answer.strip())
        else:
            st.warning("Please provide an answer before submitting")

def main():
    st.set_page_config(
        page_title="Job Readiness Assistant",
        page_icon="💼",
        layout="wide"
    )
    
    st.title("💼 Job Readiness Assistant")
    st.write("Practice your interview skills with our AI-powered bot")
    
    run_interview()

if __name__ == "__main__":
    main()