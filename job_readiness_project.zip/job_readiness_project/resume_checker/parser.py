# resume_checker/parser.py

import PyPDF2
from io import BytesIO

def parse_resume(uploaded_file):
    """Parse the uploaded PDF resume."""
    pdf = PyPDF2.PdfReader(BytesIO(uploaded_file.read()))
    text = ""
    for page in pdf.pages:
        text += page.extract_text()
    return text
