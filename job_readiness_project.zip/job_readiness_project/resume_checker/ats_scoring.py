# # resume_checker/ats_scoring.py

# def ats_score(resume_text):
#     """Basic ATS score based on keyword matching."""
#     keywords = ["Python", "Java", "C++", "Data Structures", "Algorithms", "System Design", "Machine Learning", "AI"]
#     score = 0
#     for word in keywords:
#         if word.lower() in resume_text.lower():
#             score += 1
#     return score

# import re
# import string
# from collections import Counter
# import nltk
# import logging

# # Configure logging
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# class NLTKManager:
#     """Handles NLTK resource downloads with fallbacks"""
#     @staticmethod
#     def download_resources():
#         try:
#             nltk.data.find('tokenizers/punkt')
#         except LookupError:
#             try:
#                 nltk.download('punkt', quiet=True)
#                 nltk.download('stopwords', quiet=True)
#             except Exception as e:
#                 logger.warning(f"NLTK download failed: {e}")
#                 return False
#         return True

# class ResumeScorer:
#     def __init__(self):
#         self.nltk_available = NLTKManager.download_resources()
        
#         if self.nltk_available:
#             from nltk.corpus import stopwords
#             from nltk.tokenize import word_tokenize
#             self.stopwords = set(stopwords.words('english'))
#             self.word_tokenize = word_tokenize
#         else:
#             self.stopwords = set()
#             self.word_tokenize = lambda text: text.split()
#             logger.warning("Using fallback text processing without NLTK")

#         # Keyword configuration
#         self.tech_keywords = {
#             'programming': ['python', 'java', 'javascript', 'c++', 'typescript'],
#             'web': ['html', 'css', 'react', 'angular', 'vue'],
#             'data': ['sql', 'mysql', 'mongodb', 'pandas', 'numpy'],
#             'devops': ['docker', 'kubernetes', 'aws', 'azure', 'ci/cd'],
#             'ml': ['machine learning', 'deep learning', 'tensorflow', 'pytorch']
#         }

#         # Section patterns
#         self.section_patterns = {
#             'experience': r'(experience|work\s*history|employment)',
#             'education': r'(education|academic\s*background)',
#             'skills': r'(skills|technical\s*skills)',
#             'projects': r'(projects|personal\s*projects)'
#         }

#     def preprocess_text(self, text):
#         """Basic text normalization"""
#         text = text.lower()
#         text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
#         return re.sub(r'\s+', ' ', text).strip()  # Normalize whitespace

#     def calculate_score(self, resume_text, job_description=None):
#         """Main scoring function with error handling"""
#         try:
#             resume_text = self.preprocess_text(resume_text)
            
#             scores = {
#                 'keywords': self._keyword_score(resume_text),
#                 'sections': self._section_score(resume_text),
#                 'experience': self._experience_score(resume_text),
#                 'education': self._education_score(resume_text),
#                 'achievements': self._achievement_score(resume_text),
#                 'readability': self._readability_score(resume_text),
#                 'custom': self._custom_score(resume_text, job_description) if job_description else 0
#             }
            
#             total = sum(scores.values())
#             max_score = 100  # Our scoring system maxes at 100
            
#             return {
#                 'score': total,
#                 'max_score': max_score,
#                 'percentage': round((total/max_score)*100, 1),
#                 'breakdown': scores,
#                 'feedback': self._generate_feedback(scores),
#                 'parsed_text': resume_text,
#                 'warnings': [] if self.nltk_available else ["NLTK resources not available - using basic analysis"]
#             }
            
#         except Exception as e:
#             logger.error(f"Scoring error: {str(e)}")
#             return {
#                 'error': str(e),
#                 'parsed_text': resume_text if 'resume_text' in locals() else ""
#             }

#     # [Include all scoring methods from previous implementation]
#     # _keyword_score(), _section_score(), etc.

# def ats_score(resume_text, job_description=None):
#     """Public interface for scoring"""
#     scorer = ResumeScorer()
#     return scorer.calculate_score(resume_text, job_description)

import re
import string
from collections import Counter
import nltk
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class NLTKManager:
    """Handles NLTK resource downloads with fallbacks"""
    @staticmethod
    def download_resources():
        try:
            # Try to initialize NLTK resources
            nltk.download('punkt', quiet=True)
            nltk.download('stopwords', quiet=True)
            return True
        except Exception as e:
            logger.warning(f"NLTK download failed: {e}")
            return False

class ResumeScorer:
    def __init__(self):
        self.nltk_available = NLTKManager.download_resources()
        
        try:
            if self.nltk_available:
                from nltk.corpus import stopwords
                from nltk.tokenize import word_tokenize
                try:
                    self.stopwords = set(stopwords.words('english'))
                except LookupError:
                    logger.warning("Stopwords not available, using empty stopword set")
                    self.stopwords = set()
                self.word_tokenize = word_tokenize
            else:
                self.stopwords = set()
                self.word_tokenize = lambda text: text.split()
                logger.warning("Using fallback text processing without NLTK")
        except Exception as e:
            logger.warning(f"Error initializing NLP tools: {e}")
            self.stopwords = set()
            self.word_tokenize = lambda text: text.split()
            logger.warning("Using fallback text processing due to initialization error")

        # Keyword configuration
        self.tech_keywords = {
            'programming': ['python', 'java', 'javascript', 'c++', 'typescript'],
            'web': ['html', 'css', 'react', 'angular', 'vue'],
            'data': ['sql', 'mysql', 'mongodb', 'pandas', 'numpy'],
            'devops': ['docker', 'kubernetes', 'aws', 'azure', 'ci/cd'],
            'ml': ['machine learning', 'deep learning', 'tensorflow', 'pytorch']
        }

        # Section patterns
        self.section_patterns = {
            'experience': r'(experience|work\s*history|employment)',
            'education': r'(education|academic\s*background)',
            'skills': r'(skills|technical\s*skills)',
            'projects': r'(projects|personal\s*projects)'
        }

    def preprocess_text(self, text):
        """Basic text normalization"""
        text = text.lower()
        text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
        return re.sub(r'\s+', ' ', text).strip()  # Normalize whitespace

    def _keyword_score(self, text):
        """Score based on technical keywords presence"""
        score = 0
        all_keywords = [keyword for sublist in self.tech_keywords.values() for keyword in sublist]
        
        # Check for keyword presence
        for keyword in all_keywords:
            if keyword in text:
                score += 1
                
        # Score from 0-20 based on keyword coverage
        return min(20, score * 2)
    
    def _section_score(self, text):
        """Score based on presence of standard resume sections"""
        score = 0
        # Check for each section
        for section_name, pattern in self.section_patterns.items():
            if re.search(pattern, text, re.IGNORECASE):
                score += 5
        return score
    
    def _experience_score(self, text):
        """Score based on experience descriptions"""
        # Look for action verbs commonly used in resumes
        action_verbs = ['developed', 'implemented', 'managed', 'led', 'created', 
                       'designed', 'improved', 'achieved', 'reduced', 'increased']
        
        score = 0
        for verb in action_verbs:
            if verb in text:
                score += 1
                
        # Look for quantifiable achievements
        numbers = len(re.findall(r'\d+%|\d+x|\$\d+|\d+ years', text))
        score += min(5, numbers)
        
        return min(15, score)
    
    def _education_score(self, text):
        """Score based on education section"""
        # Check for common degree terms
        degrees = ["bachelor", "master", "phd", "degree", "diploma", "certification"]
        score = 0
        
        for degree in degrees:
            if degree in text:
                score += 2
                
        # Check for specific fields of study
        fields = ["computer science", "engineering", "information technology", 
                 "data science", "mathematics", "statistics"]
        
        for field in fields:
            if field in text:
                score += 1
                
        return min(10, score)
    
    def _achievement_score(self, text):
        """Score based on achievements and accomplishments"""
        # Look for achievement indicators
        achievement_indicators = ["award", "recognition", "honor", "scholarship", 
                                 "certified", "published", "patent", "improved", 
                                 "increased", "decreased", "reduced", "saved"]
        
        score = 0
        for indicator in achievement_indicators:
            if indicator in text:
                score += 1
                
        # Give bonus for quantifiable results
        metrics = len(re.findall(r'\d+%|\d+x|\$\d+|\d+ times', text))
        score += min(5, metrics * 2)
        
        return min(15, score)
    
    def _readability_score(self, text):
        """Score based on readability and conciseness"""
        try:
            # Basic metrics - handle potential errors with tokenization
            try:
                words = self.word_tokenize(text)
            except Exception:
                # Fallback if tokenization fails
                words = text.split()
            
            filtered_words = [word for word in words if word.lower() not in self.stopwords]
            
            # Average sentence length (approximation)
            sentences = text.split('. ')
            avg_sentence_length = len(words) / max(1, len(sentences))
            
            # Vocabulary diversity
            vocabulary_diversity = len(set(filtered_words)) / max(1, len(filtered_words))
            
            # Penalty for very long or very short sentences
            penalty = 0
            if avg_sentence_length > 25:  # Too long sentences
                penalty = min(5, (avg_sentence_length - 25) / 5)
            elif avg_sentence_length < 5:  # Too short sentences
                penalty = min(5, (5 - avg_sentence_length))
                
            # Calculate readability score
            score = 10  # Base score
            score += min(5, vocabulary_diversity * 10)  # Reward for vocabulary diversity
            score -= penalty  # Apply penalty
            
            return max(0, min(10, round(score)))
        except Exception as e:
            logger.warning(f"Error in readability scoring: {e}")
            return 5  # Default middle score on error
    
    def _custom_score(self, resume_text, job_description):
        """Score based on matching with job description"""
        if not job_description:
            return 0
            
        try:
            job_text = self.preprocess_text(job_description)
            
            # Safely tokenize with fallback
            try:
                job_words = [word for word in self.word_tokenize(job_text) 
                            if word not in self.stopwords and len(word) > 2]
            except Exception:
                # Fallback tokenization
                job_words = [word for word in job_text.split()
                            if word not in self.stopwords and len(word) > 2]
            
            # Count frequency of terms in job description
            job_word_freq = Counter(job_words)
            
            # Get most important terms (based on frequency)
            important_terms = [word for word, count in job_word_freq.most_common(20)]
            
            # Score based on matching important terms
            matches = 0
            for term in important_terms:
                if term in resume_text:
                    matches += 1
                    
            return min(10, matches)
        except Exception as e:
            logger.warning(f"Error in custom scoring: {e}")
            return 0  # Default score on error
    
    def _generate_feedback(self, scores):
        """Generate feedback based on scores"""
        feedback = []
        
        # Keyword feedback
        if scores['keywords'] < 10:
            feedback.append("Consider adding more relevant technical keywords to your resume.")
        
        # Section feedback
        if scores['sections'] < 15:
            feedback.append("Make sure your resume includes clearly labeled sections for experience, education, skills, and projects.")
        
        # Experience feedback
        if scores['experience'] < 10:
            feedback.append("Enhance your experience descriptions with more action verbs and quantifiable achievements.")
        
        # Education feedback
        if scores['education'] < 5:
            feedback.append("Your education section could be more detailed or prominent.")
        
        # Achievement feedback
        if scores['achievements'] < 8:
            feedback.append("Try to include more measurable achievements and recognitions.")
        
        # Readability feedback
        if scores['readability'] < 7:
            feedback.append("Improve the readability of your resume with clearer, more concise sentences.")
            
        # Add positive feedback for good scores
        if sum(scores.values()) >= 70:
            feedback.append("Your resume has good ATS compatibility overall.")
            
        return feedback

    def calculate_score(self, resume_text, job_description=None):
        """Main scoring function with error handling"""
        try:
            resume_text = self.preprocess_text(resume_text)
            
            scores = {
                'keywords': self._keyword_score(resume_text),
                'sections': self._section_score(resume_text),
                'experience': self._experience_score(resume_text),
                'education': self._education_score(resume_text),
                'achievements': self._achievement_score(resume_text),
                'readability': self._readability_score(resume_text),
                'custom': self._custom_score(resume_text, job_description) if job_description else 0
            }
            
            total = sum(scores.values())
            max_score = 100  # Our scoring system maxes at 100
            
            return {
                'score': total,
                'max_score': max_score,
                'percentage': round((total/max_score)*100, 1),
                'breakdown': scores,
                'feedback': self._generate_feedback(scores),
                'parsed_text': resume_text,
                'warnings': [] if self.nltk_available else ["NLTK resources not available - using basic analysis"]
            }
            
        except Exception as e:
            logger.error(f"Scoring error: {str(e)}")
            return {
                'error': str(e),
                'parsed_text': resume_text if 'resume_text' in locals() else ""
            }

def ats_score(resume_text, job_description=None):
    """Public interface for scoring"""
    scorer = ResumeScorer()
    return scorer.calculate_score(resume_text, job_description)