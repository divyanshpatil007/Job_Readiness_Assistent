# self_assessment/assessment.py

questions = [
    {
        "question": "How confident are you with coding interviews?",
        "options": ["Not confident", "Somewhat confident", "Very confident"],
        "scores": [1, 2, 3]
    },
    {
        "question": "How often do you practice data structures and algorithms?",
        "options": ["Rarely", "Sometimes", "Regularly"],
        "scores": [1, 2, 3]
    },
    {
        "question": "How comfortable are you with system design concepts?",
        "options": ["Not comfortable", "Basic understanding", "Very comfortable"],
        "scores": [1, 2, 3]
    },
    {
        "question": "How well do you understand resume writing for ATS?",
        "options": ["No idea", "Somewhat familiar", "Very familiar"],
        "scores": [1, 2, 3]
    },
    {
        "question": "How often do you participate in mock interviews?",
        "options": ["Never", "Sometimes", "Frequently"],
        "scores": [1, 2, 3]
    }
]

def ask_questions():
    return questions

def calculate_score(responses):
    return sum(responses)

def get_assessment_result(score):
    if score <= 7:
        return "Needs Improvement"
    elif score <= 11:
        return "Moderate Readiness"
    else:
        return "Job Ready"
